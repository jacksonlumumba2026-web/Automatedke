import { NextResponse } from "next/server";

/**
 * Liveness endpoint polled by external uptime monitoring
 * (Engineering_Standards.md, Section 3.1). Deliberately does not touch
 * the database — a DB-dependent health check would conflate "app is up"
 * with "database is reachable," which are different failure modes that
 * should page differently.
 */
export async function GET() {
  return NextResponse.json({ status: "ok", timestamp: new Date().toISOString() });
}
