import type { Metadata } from "next";
import { Inter } from "next/font/google";

import "./globals.css";

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  display: "swap",
});

export const metadata: Metadata = {
  title: {
    default: "Automated KE — Run your business, automatically",
    template: "%s | Automated KE",
  },
  description:
    "CRM, accounting, inventory, HR, and AI automation in one platform, built for Kenyan and African businesses.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={inter.variable} suppressHydrationWarning>
      <body className="min-h-screen bg-background font-sans text-text-primary antialiased dark:bg-background-dark dark:text-text-primary-dark">
        {children}
      </body>
    </html>
  );
}
