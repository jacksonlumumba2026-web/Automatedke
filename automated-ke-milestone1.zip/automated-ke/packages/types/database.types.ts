/**
 * MANUALLY-AUTHORED STAND-IN, matching database_schema.sql exactly.
 *
 * This file exists so the codebase typechecks in Step 1 before a live
 * Supabase project exists. It MUST be replaced by running:
 *   pnpm db:types
 * against the real project in Step 2, and this comment block removed
 * once that happens. Do not hand-edit after that point.
 */

export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[];

export interface Database {
  public: {
    Tables: {
      organizations: {
        Row: {
          id: string;
          name: string;
          slug: string;
          industry: string | null;
          country: string;
          enabled_modules: Json;
          settings: Json;
          created_at: string;
          updated_at: string;
          deleted_at: string | null;
        };
        Insert: {
          id?: string;
          name: string;
          slug: string;
          industry?: string | null;
          country?: string;
          enabled_modules?: Json;
          settings?: Json;
          created_at?: string;
          updated_at?: string;
          deleted_at?: string | null;
        };
        Update: Partial<Database["public"]["Tables"]["organizations"]["Insert"]>;
      };
      users: {
        Row: {
          id: string;
          full_name: string | null;
          avatar_url: string | null;
          phone: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id: string;
          full_name?: string | null;
          avatar_url?: string | null;
          phone?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: Partial<Database["public"]["Tables"]["users"]["Insert"]>;
      };
      organization_members: {
        Row: {
          id: string;
          organization_id: string;
          user_id: string;
          role: OrgRole;
          status: "active" | "suspended";
          invited_by: string | null;
          joined_at: string;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          organization_id: string;
          user_id: string;
          role?: OrgRole;
          status?: "active" | "suspended";
          invited_by?: string | null;
          joined_at?: string;
          created_at?: string;
          updated_at?: string;
        };
        Update: Partial<Database["public"]["Tables"]["organization_members"]["Insert"]>;
      };
      teams: {
        Row: {
          id: string;
          organization_id: string;
          name: string;
          description: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          organization_id: string;
          name: string;
          description?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: Partial<Database["public"]["Tables"]["teams"]["Insert"]>;
      };
      team_members: {
        Row: { team_id: string; user_id: string; created_at: string };
        Insert: { team_id: string; user_id: string; created_at?: string };
        Update: Partial<Database["public"]["Tables"]["team_members"]["Insert"]>;
      };
      role_permissions: {
        Row: {
          id: string;
          organization_id: string;
          role: OrgRole;
          module: string;
          can_view: boolean;
          can_create: boolean;
          can_edit: boolean;
          can_delete: boolean;
          can_export: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          organization_id: string;
          role: OrgRole;
          module: string;
          can_view?: boolean;
          can_create?: boolean;
          can_edit?: boolean;
          can_delete?: boolean;
          can_export?: boolean;
          created_at?: string;
          updated_at?: string;
        };
        Update: Partial<Database["public"]["Tables"]["role_permissions"]["Insert"]>;
      };
      invitations: {
        Row: {
          id: string;
          organization_id: string;
          email: string;
          role: OrgRole;
          token: string;
          invited_by: string;
          status: "pending" | "accepted" | "expired" | "revoked";
          expires_at: string;
          created_at: string;
        };
        Insert: {
          id?: string;
          organization_id: string;
          email: string;
          role?: OrgRole;
          token?: string;
          invited_by: string;
          status?: "pending" | "accepted" | "expired" | "revoked";
          expires_at?: string;
          created_at?: string;
        };
        Update: Partial<Database["public"]["Tables"]["invitations"]["Insert"]>;
      };
      subscriptions: {
        Row: {
          id: string;
          organization_id: string;
          plan: SubscriptionPlan;
          status: "active" | "past_due" | "canceled" | "trialing";
          current_period_end: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          organization_id: string;
          plan?: SubscriptionPlan;
          status?: "active" | "past_due" | "canceled" | "trialing";
          current_period_end?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: Partial<Database["public"]["Tables"]["subscriptions"]["Insert"]>;
      };
      notifications: {
        Row: {
          id: string;
          organization_id: string;
          user_id: string;
          type: string;
          title: string;
          body: string | null;
          read_at: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          organization_id: string;
          user_id: string;
          type: string;
          title: string;
          body?: string | null;
          read_at?: string | null;
          created_at?: string;
        };
        Update: Partial<Database["public"]["Tables"]["notifications"]["Insert"]>;
      };
      audit_logs: {
        Row: {
          id: string;
          organization_id: string | null;
          user_id: string | null;
          action: string;
          entity_type: string;
          entity_id: string | null;
          old_data: Json | null;
          new_data: Json | null;
          ip_address: string | null;
          created_at: string;
        };
        Insert: never; // insert-only via trigger — application code never inserts directly
        Update: never; // immutable — no update policy exists
      };
    };
    Views: Record<string, never>;
    Functions: {
      user_org_ids: { Args: Record<string, never>; Returns: string[] };
      user_role_in_org: { Args: { p_org_id: string }; Returns: OrgRole };
    };
    Enums: {
      org_role: OrgRole;
      subscription_plan: SubscriptionPlan;
    };
  };
}

export type OrgRole =
  | "owner"
  | "admin"
  | "manager"
  | "accountant"
  | "sales_rep"
  | "hr_manager"
  | "inventory_staff"
  | "support_agent"
  | "read_only"
  | "custom";

export type SubscriptionPlan = "free" | "starter" | "professional" | "business" | "enterprise";
