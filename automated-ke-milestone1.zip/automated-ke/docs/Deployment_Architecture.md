# Deployment Architecture — Phase 1

## 1. Environments

Three fully separated environments, each its own Supabase project (not schemas within one project — full isolation prevents a staging mistake from ever touching production data):

| Environment | Purpose | Next.js Hosting | Database |
|---|---|---|---|
| **Local** | Individual development | `next dev` | Supabase CLI local stack (Docker) |
| **Staging** | Pre-production validation, PR previews | Vercel Preview Deployments | Dedicated Supabase staging project |
| **Production** | Live platform | Vercel Production | Dedicated Supabase production project |

Every environment uses the identical migration history — staging is promoted-to, never independently modified, so what's tested in staging is exactly what ships to production.

## 2. Hosting Topology

- **Frontend/app:** Vercel (Next.js-native hosting — edge network, automatic HTTPS, serverless/edge functions for route handlers and server actions). Chosen over a self-managed container setup because it removes an entire category of ops work (SSL, CDN, scaling) that has no product value at this stage.
- **Backend:** Supabase managed (Postgres, Auth, Storage, Edge Functions, Realtime) — same reasoning: managed infrastructure lets engineering time go into the product, not into running Postgres.
- **Domain/DNS:** primary domain points to Vercel; Supabase project URL used only for API calls, never customer-facing.

## 3. CI/CD Pipeline

Trigger: every pull request and every merge to `main`.

**PR pipeline (GitHub Actions):**
1. Install dependencies (pnpm, cached).
2. Lint + typecheck (`turbo lint typecheck`).
3. Unit + integration tests.
4. **Migration diff check** — a bot compares `supabase/migrations/` against the target environment's applied migrations and fails the PR if a migration file was edited after being merged (migrations are append-only, never retroactively changed).
5. Vercel automatically builds a Preview Deployment for the PR, pointed at the staging Supabase project.

**Merge-to-main pipeline:**
1. All PR checks re-run.
2. `supabase db push` applies any new migrations to the **production** Supabase project — run in CI, never manually via a developer's local CLI against production.
3. Type generation (`supabase gen types typescript`) re-runs against the now-updated production schema and is committed if changed, keeping `packages/types` authoritative.
4. Vercel promotes the build to production.

**Ordering guarantee:** database migrations always apply *before* the new frontend build goes live — the app code is never running against a schema it doesn't expect.

## 4. Secrets Management

- Environment variables scoped per-environment in Vercel (local/staging/production have independent values, never shared).
- Supabase **service role key** (bypasses RLS) exists only in server-side environment variables, used only in `lib/supabase/admin.ts` and Edge Functions — never sent to the browser, never referenced in any `"use client"` file (enforced by code review and, ideally, a lint rule scanning for the env var name outside allow-listed files).
- OAuth client secrets (Google, Microsoft) configured in Supabase Auth provider settings, not duplicated into the Next.js app's own env vars.
- `.env.example` documents every required variable name with placeholder values — no real secret ever committed, including in example form.

## 5. Rollback Strategy

- **Frontend:** Vercel supports instant rollback to any previous deployment — used for any production issue traced to frontend code, near-zero downtime.
- **Database:** migrations are written to be additive/backward-compatible wherever possible (add a column with a default, don't rename in place — rename via add-new/migrate-data/drop-old across separate deploys) specifically so a frontend rollback never lands against an incompatible schema.
- For migrations that can't avoid being breaking, a corresponding **down-migration** is written and tested before the up-migration ships, not written reactively during an incident.

## 6. Backup & Disaster Recovery

- Supabase automated daily backups plus Point-in-Time Recovery (PITR) enabled on the production project from day one — not deferred to "when we have real customers," since Phase 1 already stores real account/auth data the moment the first signup happens.
- **Target RTO (recovery time objective):** documented and tested, not assumed — a restore drill is part of the Phase 1 "definition of done" alongside the functional testing already specified in `Phase1_Architecture.md`.
- **Target RPO (recovery point objective):** bounded by PITR granularity (typically down to the minute on Supabase's PITR offering) — acceptable for Phase 1's data sensitivity; revisited if/when payment data (Phase 3+) raises the bar.

## 7. Scaling Posture (Phase 1 — not yet a bottleneck, documented for awareness)

- Vercel serverless/edge functions scale automatically with traffic — no capacity planning needed at Phase 1 volume.
- Supabase connection pooling (PgBouncer, built in) handles concurrent connections from serverless functions, which open/close connections far more frequently than a traditional long-running server — this is why the Technical Architecture's choice of Supabase over a self-managed Postgres instance matters operationally, not just for developer convenience.
- No caching layer (Redis, etc.) in Phase 1 — premature at this data volume; revisited if specific query patterns (e.g., dashboard aggregates) show measurable latency under real load in later phases.

## 8. Environment Parity Checklist (must hold true before Phase 1 is considered deployable)

- [ ] Staging and production Supabase projects have identical migration history.
- [ ] Staging and production have independent OAuth app registrations (different redirect URIs) — never share OAuth credentials across environments.
- [ ] `packages/types` is regenerated and committed after every migration, checked in CI so a stale type file fails the build rather than silently drifting.
- [ ] A restore-from-backup drill has been performed at least once against a non-production project before go-live.
