# RLS Policy Reference — Phase 1

Companion to `database_schema.sql`, which contains the executable policies. This document is the readable reference for what each policy enforces and why — used in code review and onboarding, so a reviewer can check intent against implementation without parsing SQL line by line.

**Governing principle:** RLS is the authorization boundary, not the application layer. Every policy below is enforced by Postgres itself — a bug in a server action, an admin script, or a future API integration cannot bypass it. Application-layer permission checks (Section 8 companion, `lib/rbac/permissions.ts`) exist for UX (hiding buttons a user can't use), never as the actual security control.

**Two helper functions underpin every policy** (defined in `database_schema.sql`):
- `user_org_ids()` — the set of organizations the current authenticated user actively belongs to.
- `user_role_in_org(org_id)` — the current user's role within a specific organization.
Both are `SECURITY DEFINER`, which is what avoids infinite recursion when a policy on `organization_members` needs to check `organization_members` membership.

---

## Policy Matrix

| Table | Operation | Who | Enforced Logic |
|---|---|---|---|
| `organizations` | SELECT | Any active member | `id in user_org_ids()` |
| `organizations` | INSERT | Any authenticated user | `auth.uid() is not null` — anyone can create a new org (becomes its owner via the onboarding flow) |
| `organizations` | UPDATE | Owner, Admin | Must be an active member **and** role in `('owner','admin')` |
| `organizations` | DELETE | *(no policy — blocked)* | Deliberate: org deletion is a soft-delete via `deleted_at`, handled through a dedicated admin-audited flow in a later phase, never a raw DELETE |
| `users` | SELECT | Self, or any co-member of a shared org | Self always visible; co-members visible so names/avatars render in member lists, activity feeds |
| `users` | UPDATE | Self only | `id = auth.uid()` |
| `organization_members` | SELECT | Any active member of that org | `organization_id in user_org_ids()` |
| `organization_members` | INSERT | Owner/Admin, or org bootstrap | Normal case: inviter must be owner/admin; bootstrap case (org has zero members) allows the creating user to insert themselves as owner |
| `organization_members` | UPDATE | Owner, Admin | Role changes restricted to owner/admin |
| `organization_members` | DELETE | Owner, Admin | Removing a member restricted to owner/admin |
| `teams` / `team_members` | SELECT | Any active member | Scoped via `organization_id in user_org_ids()` |
| `teams` | ALL (write) | Owner, Admin, Manager | Managers can organize their own teams without needing full admin rights |
| `role_permissions` | SELECT | Any active member | Members can see what their role can/can't do (transparency, supports good UX for permission-denied states) |
| `role_permissions` | INSERT/UPDATE/DELETE | Owner, Admin | Only org leadership can redefine what a role is permitted to do |
| `invitations` | SELECT | Owner, Admin | Only leadership sees pending invitations for their org |
| `invitations` | INSERT | Owner, Admin | Only leadership can invite |
| `invitations` | UPDATE | Owner, Admin | Revocation only by leadership |
| `invitations` | *(token lookup)* | Handled outside RLS | Acceptance flow uses a `SECURITY DEFINER` function keyed by the invitation token itself — the token is the credential, not row-level org membership (the accepting user isn't a member yet) |
| `subscriptions` | SELECT | Any active member | Visible to all so non-owners understand plan limits in the UI |
| `subscriptions` | UPDATE | Owner only | Billing changes restricted to the single owner role, not admins |
| `notifications` | SELECT | Recipient only | `user_id = auth.uid()` — notifications are never org-visible, only to the intended recipient |
| `notifications` | UPDATE | Recipient only | Marking read/unread |
| `audit_logs` | SELECT | Owner, Admin | Only leadership can review the audit trail |
| `audit_logs` | INSERT/UPDATE/DELETE | *(no user-facing policy)* | Writes occur exclusively via the `SECURITY DEFINER` trigger function, which bypasses RLS entirely — this makes the log tamper-resistant to every role, including owner |

---

## Testing Requirement

Per coding standards, every policy above must have at least one automated test that:
1. Confirms a legitimate access pattern succeeds.
2. Confirms the equivalent cross-tenant access attempt (same query, different `organization_id` the user doesn't belong to) returns zero rows or is rejected — never returns another tenant's data.

This is tested directly against the database (e.g., via `pgTAP` or a script issuing queries as different authenticated roles), not only indirectly through the application UI.
