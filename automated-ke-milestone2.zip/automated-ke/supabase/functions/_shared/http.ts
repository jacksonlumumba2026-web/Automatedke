// Shared across all Edge Functions in supabase/functions/.
export const corsHeaders = {
  "Access-Control-Allow-Origin": Deno.env.get("SITE_URL") ?? "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

export function jsonResponse(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

// Matches the standard error shape from Engineering_Standards.md Part 1
// and apps/web/lib/errors.ts — one contract across the whole platform.
export function errorResponse(code: string, message: string, status: number) {
  return jsonResponse({ data: null, error: { code, message, details: null } }, status);
}
