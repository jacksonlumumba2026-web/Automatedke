import "server-only";

import { createClient } from "@/lib/supabase/server";

export type Subscription = {
  plan: string;
  status: string;
  current_period_end: string | null;
};

export async function getSubscription(organizationId: string): Promise<Subscription | null> {
  const supabase = await createClient();
  const { data } = await supabase
    .from("subscriptions")
    .select("plan, status, current_period_end")
    .eq("organization_id", organizationId)
    .single();

  return data;
}
