import "server-only";

import { createClient } from "@/lib/supabase/server";

export type RolePermissionRow = {
  role: string;
  module: string;
  can_view: boolean;
  can_create: boolean;
  can_edit: boolean;
  can_delete: boolean;
  can_export: boolean;
};

export async function getRolePermissions(organizationId: string): Promise<RolePermissionRow[]> {
  const supabase = await createClient();
  const { data } = await supabase
    .from("role_permissions")
    .select("role, module, can_view, can_create, can_edit, can_delete, can_export")
    .eq("organization_id", organizationId);

  return data ?? [];
}
