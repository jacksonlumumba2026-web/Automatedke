import type { ToastVariant } from "@/components/ui/Toast";

const KEY = "automated-ke:pending-toast";

/**
 * Call right before a client-side redirect (router.push) when the
 * mutation succeeded on the page being navigated AWAY from — e.g.
 * "Organization created" or "Password updated." A toast fired on the
 * unmounting page would never be seen; this defers it to the next page.
 */
export function setPendingToast(message: string, variant: ToastVariant = "success") {
  if (typeof window === "undefined") return;
  sessionStorage.setItem(KEY, JSON.stringify({ message, variant }));
}

export function takePendingToast(): { message: string; variant: ToastVariant } | null {
  if (typeof window === "undefined") return null;
  const raw = sessionStorage.getItem(KEY);
  if (!raw) return null;
  sessionStorage.removeItem(KEY);
  try {
    return JSON.parse(raw);
  } catch {
    return null;
  }
}
