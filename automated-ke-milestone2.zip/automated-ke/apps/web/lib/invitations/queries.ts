import "server-only";

import { createClient } from "@/lib/supabase/server";

export type TeamMember = {
  id: string;
  role: string;
  status: string;
  joined_at: string;
  users: { id: string; full_name: string | null } | null;
};

export type PendingInvitation = {
  id: string;
  email: string;
  role: string;
  status: string;
  expires_at: string;
};

export async function getTeamMembers(organizationId: string): Promise<TeamMember[]> {
  const supabase = await createClient();
  const { data } = await supabase
    .from("organization_members")
    .select("id, role, status, joined_at, users(id, full_name)")
    .eq("organization_id", organizationId)
    .order("joined_at", { ascending: true });

  return (data as unknown as TeamMember[]) ?? [];
}

export async function getPendingInvitations(organizationId: string): Promise<PendingInvitation[]> {
  const supabase = await createClient();
  const { data } = await supabase
    .from("invitations")
    .select("id, email, role, status, expires_at")
    .eq("organization_id", organizationId)
    .eq("status", "pending")
    .order("created_at", { ascending: false });

  return data ?? [];
}
