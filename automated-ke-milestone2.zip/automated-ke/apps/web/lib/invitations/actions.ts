"use server";

import { revalidatePath } from "next/cache";

import { requireOrgAccess, assertOrgRole } from "@/lib/auth/guards";
import { fail, mapSupabaseError, ok, type AppResult } from "@/lib/errors";
import { createClient } from "@/lib/supabase/server";
import { sendInvitationSchema, type SendInvitationInput } from "@/lib/validators/invitation";

export async function sendInvitation(
  orgSlug: string,
  input: SendInvitationInput
): Promise<AppResult<{ invited: true }>> {
  const parsed = sendInvitationSchema.safeParse(input);
  if (!parsed.success) {
    const details: Record<string, string[]> = {};
    for (const issue of parsed.error.issues) {
      const key = String(issue.path[0] ?? "form");
      details[key] = [...(details[key] ?? []), issue.message];
    }
    return fail("VALIDATION_ERROR", "Please fix the errors below.", details);
  }

  const context = await requireOrgAccess(orgSlug);
  assertOrgRole(context, ["owner", "admin"]); // mirrors canManageTeam — see lib/rbac/permissions.ts

  const supabase = await createClient();

  // Defense in depth: RLS also enforces owner/admin-only insert on
  // `invitations` (see RLS_Policy_Reference.md) — this check is not the
  // only thing standing between a non-admin and this action.
  const { error } = await supabase.from("invitations").insert({
    organization_id: context.organization.id,
    email: parsed.data.email,
    role: parsed.data.role as SendInvitationInput["role"],
    invited_by: context.user.id,
  });

  if (error) {
    const mapped = mapSupabaseError(error);
    if (mapped.code === "CONFLICT") {
      return fail("CONFLICT", "There's already a pending invitation for this email.");
    }
    return fail(mapped.code, mapped.message);
  }

  // Actual email delivery (transactional email provider) is Phase 5
  // Marketing/Automation infrastructure per Phase1_Architecture.md Step
  // 8 — the invitation row and its token exist and are fully functional
  // via direct link in the meantime; only the notification channel is
  // deferred, not the feature.
  revalidatePath(`/${orgSlug}/settings`);
  return ok({ invited: true });
}

export async function revokeInvitation(orgSlug: string, invitationId: string): Promise<AppResult<{ revoked: true }>> {
  const context = await requireOrgAccess(orgSlug);
  assertOrgRole(context, ["owner", "admin"]);

  const supabase = await createClient();
  const { error } = await supabase
    .from("invitations")
    .update({ status: "revoked" })
    .eq("id", invitationId)
    .eq("organization_id", context.organization.id);

  if (error) {
    const mapped = mapSupabaseError(error);
    return fail(mapped.code, mapped.message);
  }

  revalidatePath(`/${orgSlug}/settings`);
  return ok({ revoked: true });
}

export async function acceptInvitation(
  token: string
): Promise<AppResult<{ orgSlug: string }>> {
  const supabase = await createClient();
  const { data, error } = await supabase.rpc("accept_invitation", { p_token: token });

  if (error) {
    if (error.message.includes("AUTH_REQUIRED")) {
      return fail("AUTH_REQUIRED", "Please sign in to accept this invitation.");
    }
    if (error.message.includes("INVITATION_NOT_FOUND")) {
      return fail("INVITATION_NOT_FOUND", "This invitation link isn't valid.");
    }
    if (error.message.includes("INVITATION_ALREADY_ACCEPTED")) {
      return fail("INVITATION_ALREADY_ACCEPTED", "This invitation has already been used. Try signing in instead.");
    }
    if (error.message.includes("INVITATION_REVOKED")) {
      return fail("INVITATION_REVOKED", "This invitation has been revoked. Ask for a new one.");
    }
    if (error.message.includes("INVITATION_EXPIRED")) {
      return fail("INVITATION_EXPIRED", "This invitation link has expired. Ask for a new one.");
    }
    if (error.message.includes("EMAIL_MISMATCH")) {
      return fail("EMAIL_MISMATCH", "Sign in with the email address this invitation was sent to.");
    }
    return fail("INTERNAL_ERROR", "Something went wrong. Please try again.");
  }

  const row = Array.isArray(data) ? data[0] : data;
  if (!row?.organization_slug) {
    return fail("INTERNAL_ERROR", "Something went wrong. Please try again.");
  }

  return ok({ orgSlug: row.organization_slug });
}
