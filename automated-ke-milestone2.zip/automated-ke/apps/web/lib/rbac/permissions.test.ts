import { describe, expect, it } from "vitest";

import {
  canManageBilling,
  canManageRoles,
  canManageTeam,
  canUpdateOrganization,
  canViewBilling,
  canViewRoles,
} from "./permissions";
import type { OrgRole } from "./constants";

const ALL_ROLES: OrgRole[] = [
  "owner",
  "admin",
  "manager",
  "accountant",
  "sales_rep",
  "hr_manager",
  "inventory_staff",
  "support_agent",
  "read_only",
  "custom",
];

describe("canManageTeam", () => {
  it("allows only owner and admin", () => {
    for (const role of ALL_ROLES) {
      const expected = role === "owner" || role === "admin";
      expect(canManageTeam(role)).toBe(expected);
    }
  });
});

describe("canManageRoles", () => {
  it("allows only owner and admin", () => {
    for (const role of ALL_ROLES) {
      const expected = role === "owner" || role === "admin";
      expect(canManageRoles(role)).toBe(expected);
    }
  });
});

describe("canManageBilling", () => {
  it("allows only owner — not even admin", () => {
    expect(canManageBilling("owner")).toBe(true);
    for (const role of ALL_ROLES.filter((r) => r !== "owner")) {
      expect(canManageBilling(role)).toBe(false);
    }
  });
});

describe("canViewBilling", () => {
  it("allows owner, admin, and accountant — matches Permission_Matrix.md exactly", () => {
    const allowed: OrgRole[] = ["owner", "admin", "accountant"];
    for (const role of ALL_ROLES) {
      expect(canViewBilling(role)).toBe(allowed.includes(role));
    }
  });
});

describe("canViewRoles", () => {
  it("allows only owner and admin — a Manager cannot even view role permissions", () => {
    for (const role of ALL_ROLES) {
      const expected = role === "owner" || role === "admin";
      expect(canViewRoles(role)).toBe(expected);
    }
  });
});

describe("canUpdateOrganization", () => {
  it("allows only owner and admin", () => {
    for (const role of ALL_ROLES) {
      const expected = role === "owner" || role === "admin";
      expect(canUpdateOrganization(role)).toBe(expected);
    }
  });
});
