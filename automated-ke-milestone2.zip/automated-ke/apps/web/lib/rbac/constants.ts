import type { Database } from "@automated-ke/types";

export type OrgRole = Database["public"]["Enums"]["org_role"];

export const ORG_ROLES: { value: OrgRole; label: string }[] = [
  { value: "owner", label: "Owner" },
  { value: "admin", label: "Admin" },
  { value: "manager", label: "Manager" },
  { value: "accountant", label: "Accountant" },
  { value: "sales_rep", label: "Sales Rep" },
  { value: "hr_manager", label: "HR Manager" },
  { value: "inventory_staff", label: "Inventory Staff" },
  { value: "support_agent", label: "Support Agent" },
  { value: "read_only", label: "Read Only" },
  { value: "custom", label: "Custom" },
];

/** Phase 1 modules only — Phase 2+ modules are added here as they ship. */
export const PLATFORM_MODULES = ["organization", "team", "roles", "billing", "notifications"] as const;
export type PlatformModule = (typeof PLATFORM_MODULES)[number];

/**
 * Centralized status -> Badge variant mapping (Component_Library.md,
 * <Badge> section: "this mapping is centralized ... so a given status
 * always renders the same color everywhere in the product").
 */
export function statusToBadgeVariant(
  status: string
): "default" | "success" | "warning" | "danger" | "info" {
  const success = ["active", "paid", "completed", "accepted", "confirmed"];
  const warning = ["pending", "trialing", "trial"];
  const danger = ["suspended", "overdue", "failed", "canceled", "expired", "revoked", "past_due"];

  const normalized = status.toLowerCase();
  if (success.includes(normalized)) return "success";
  if (warning.includes(normalized)) return "warning";
  if (danger.includes(normalized)) return "danger";
  return "default";
}
