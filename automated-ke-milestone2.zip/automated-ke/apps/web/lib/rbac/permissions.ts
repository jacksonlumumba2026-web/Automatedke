import type { OrgRole } from "./constants";

/**
 * IMPORTANT: This module is the UX layer only — it decides what to show
 * or hide in the UI. It is NOT the authorization boundary; the database
 * enforces that via RLS regardless of what this returns. See CLAUDE.md
 * Rule 2 and RLS_Policy_Reference.md.
 *
 * Phase 1's own structural features (team, billing, roles) use hardcoded
 * owner/admin checks here, mirroring the hardcoded RLS policies for the
 * same tables — per Permission_Matrix.md, these are platform-level
 * capabilities, not business-configurable ones, so they intentionally do
 * NOT consult a dynamic role_permissions lookup. Phase 2+ domain modules
 * (CRM, Inventory, etc.) will add a dynamic `can()` variant that reads
 * role_permissions once those tables exist.
 */

const STRUCTURAL_ADMIN_ROLES: OrgRole[] = ["owner", "admin"];

export function canManageTeam(role: OrgRole): boolean {
  return STRUCTURAL_ADMIN_ROLES.includes(role);
}

export function canManageRoles(role: OrgRole): boolean {
  return STRUCTURAL_ADMIN_ROLES.includes(role);
}

export function canManageBilling(role: OrgRole): boolean {
  return role === "owner";
}

export function canViewBilling(role: OrgRole): boolean {
  return STRUCTURAL_ADMIN_ROLES.includes(role) || role === "accountant";
}

export function canViewRoles(role: OrgRole): boolean {
  return STRUCTURAL_ADMIN_ROLES.includes(role);
}

export function canUpdateOrganization(role: OrgRole): boolean {
  return STRUCTURAL_ADMIN_ROLES.includes(role);
}

export function canManageOrgTeamsAsManager(role: OrgRole): boolean {
  return STRUCTURAL_ADMIN_ROLES.includes(role) || role === "manager";
}
