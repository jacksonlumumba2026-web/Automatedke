import { describe, expect, it } from "vitest";

import { statusToBadgeVariant } from "./constants";

describe("statusToBadgeVariant", () => {
  it("maps active/paid/completed statuses to success", () => {
    expect(statusToBadgeVariant("active")).toBe("success");
    expect(statusToBadgeVariant("Accepted")).toBe("success"); // case-insensitive
  });

  it("maps pending/trial statuses to warning", () => {
    expect(statusToBadgeVariant("pending")).toBe("warning");
    expect(statusToBadgeVariant("trialing")).toBe("warning");
  });

  it("maps suspended/overdue/failed statuses to danger", () => {
    expect(statusToBadgeVariant("suspended")).toBe("danger");
    expect(statusToBadgeVariant("expired")).toBe("danger");
    expect(statusToBadgeVariant("revoked")).toBe("danger");
  });

  it("falls back to default for unrecognized statuses", () => {
    expect(statusToBadgeVariant("some-unknown-status")).toBe("default");
  });
});
