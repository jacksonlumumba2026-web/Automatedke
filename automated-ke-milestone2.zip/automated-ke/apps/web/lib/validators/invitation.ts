import { z } from "zod";

import { ORG_ROLES } from "@/lib/rbac/constants";

const invitableRoles = ORG_ROLES.map((r) => r.value).filter((r) => r !== "owner" && r !== "custom") as [
  string,
  ...string[],
];

export const sendInvitationSchema = z.object({
  email: z.string().trim().email("Enter a valid email address"),
  // Owner is deliberately excluded — per Permission_Matrix.md, ownership
  // transfer is a distinct, higher-stakes operation, not a regular invite.
  role: z.enum(invitableRoles as [string, ...string[]]),
});
export type SendInvitationInput = z.infer<typeof sendInvitationSchema>;
