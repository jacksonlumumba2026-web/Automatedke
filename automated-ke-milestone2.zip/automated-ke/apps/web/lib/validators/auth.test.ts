import { describe, expect, it } from "vitest";

import { loginSchema, passwordSchema, signUpSchema } from "./auth";

describe("passwordSchema", () => {
  it("rejects passwords under 10 characters", () => {
    expect(passwordSchema.safeParse("short1").success).toBe(false);
  });

  it("rejects passwords with no digit", () => {
    expect(passwordSchema.safeParse("nodigitsatall").success).toBe(false);
  });

  it("accepts a password meeting both rules", () => {
    expect(passwordSchema.safeParse("longenough1").success).toBe(true);
  });
});

describe("signUpSchema", () => {
  it("rejects an invalid email", () => {
    const result = signUpSchema.safeParse({
      fullName: "Jane Doe",
      email: "not-an-email",
      password: "longenough1",
    });
    expect(result.success).toBe(false);
  });

  it("rejects an empty full name", () => {
    const result = signUpSchema.safeParse({
      fullName: "",
      email: "jane@example.com",
      password: "longenough1",
    });
    expect(result.success).toBe(false);
  });

  it("accepts valid input", () => {
    const result = signUpSchema.safeParse({
      fullName: "Jane Doe",
      email: "jane@example.com",
      password: "longenough1",
    });
    expect(result.success).toBe(true);
  });
});

describe("loginSchema", () => {
  it("requires a non-empty password but does not enforce the full policy", () => {
    // Login must accept an existing (possibly old-policy) password —
    // only signup/reset enforce the strength policy.
    const result = loginSchema.safeParse({ email: "jane@example.com", password: "x" });
    expect(result.success).toBe(true);
  });

  it("rejects a missing password", () => {
    const result = loginSchema.safeParse({ email: "jane@example.com", password: "" });
    expect(result.success).toBe(false);
  });
});
