import { z } from "zod";

export const createOrganizationSchema = z.object({
  name: z.string().trim().min(2, "Organization name must be at least 2 characters").max(200),
  industry: z.string().trim().max(100).optional(),
  country: z.string().trim().length(2).default("KE"),
});
export type CreateOrganizationInput = z.infer<typeof createOrganizationSchema>;

export const INDUSTRY_OPTIONS = [
  { value: "retail", label: "Retail / Shop" },
  { value: "wholesale", label: "Wholesale" },
  { value: "manufacturing", label: "Manufacturing" },
  { value: "hospitality", label: "Restaurant / Hotel" },
  { value: "healthcare", label: "Hospital / Clinic" },
  { value: "education", label: "School" },
  { value: "real_estate", label: "Real Estate" },
  { value: "professional_services", label: "Professional Services (Accounting, Consulting)" },
  { value: "ngo", label: "NGO" },
  { value: "other", label: "Other" },
];
