import { describe, expect, it } from "vitest";

import { sendInvitationSchema } from "./invitation";

describe("sendInvitationSchema", () => {
  it("rejects inviting someone as owner", () => {
    const result = sendInvitationSchema.safeParse({ email: "a@example.com", role: "owner" });
    expect(result.success).toBe(false);
  });

  it("rejects inviting someone as a custom role (not yet supported)", () => {
    const result = sendInvitationSchema.safeParse({ email: "a@example.com", role: "custom" });
    expect(result.success).toBe(false);
  });

  it("accepts a valid invitable role", () => {
    const result = sendInvitationSchema.safeParse({ email: "a@example.com", role: "sales_rep" });
    expect(result.success).toBe(true);
  });

  it("rejects an invalid email", () => {
    const result = sendInvitationSchema.safeParse({ email: "not-an-email", role: "read_only" });
    expect(result.success).toBe(false);
  });
});
