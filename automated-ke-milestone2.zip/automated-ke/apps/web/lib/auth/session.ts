import "server-only";

import { redirect } from "next/navigation";

import { createClient } from "@/lib/supabase/server";

/**
 * Fetches the current authenticated user server-side. Uses
 * `auth.getUser()`, not `auth.getSession()` — getUser() revalidates the
 * token against Supabase's servers rather than trusting an unverified
 * cookie value, which matters for any check used as an authorization
 * decision (Authentication_Specification.md Section 6.6).
 */
export async function getCurrentUser() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  return user;
}

/**
 * Use at the top of any Server Component / layout that must not render
 * for an unauthenticated visitor. Middleware already redirects most
 * unauthenticated requests before this runs, but this is the
 * authoritative, defense-in-depth check — CLAUDE.md Rule 7.
 */
export async function requireAuth() {
  const user = await getCurrentUser();
  if (!user) {
    redirect("/login");
  }
  return user;
}
