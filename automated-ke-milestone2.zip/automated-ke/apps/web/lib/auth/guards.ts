import "server-only";

import { notFound } from "next/navigation";

import { createClient } from "@/lib/supabase/server";
import type { OrgRole } from "@/lib/rbac/constants";

import { requireAuth } from "./session";

export type OrgContext = {
  organization: { id: string; name: string; slug: string; enabled_modules: string[] };
  role: OrgRole;
  user: { id: string; email: string };
};

/**
 * THE authoritative tenant-access check (Phase1_Architecture.md Section 7,
 * "Organization & Multi-Tenant Architecture"). Resolves orgSlug -> org,
 * confirms the current user has an active organization_members row for
 * it, and returns both. Every route under app/(app)/[orgSlug]/ calls this
 * via the layout — no route below it re-implements this check, and none
 * should ever skip it.
 *
 * Uses notFound() rather than a distinguishing "403" page for non-members
 * — per Authentication_Specification.md Section 9, we don't reveal
 * whether a given org slug exists to someone who isn't a member of it.
 */
export async function requireOrgAccess(orgSlug: string): Promise<OrgContext> {
  const user = await requireAuth();
  const supabase = await createClient();

  const { data: org, error: orgError } = await supabase
    .from("organizations")
    .select("id, name, slug, enabled_modules")
    .eq("slug", orgSlug)
    .is("deleted_at", null)
    .single();

  if (orgError || !org) {
    notFound();
  }

  const { data: membership, error: memberError } = await supabase
    .from("organization_members")
    .select("role")
    .eq("organization_id", org.id)
    .eq("status", "active")
    .single();

  if (memberError || !membership) {
    // RLS already prevents this row from being visible to a non-member,
    // so this branch is what actually fires for non-members — the
    // .single() call above returns no row, not an "access denied" the
    // client could distinguish from "doesn't exist."
    notFound();
  }

  return {
    organization: {
      id: org.id,
      name: org.name,
      slug: org.slug,
      enabled_modules: (org.enabled_modules as string[]) ?? [],
    },
    role: membership.role as OrgRole,
    user: { id: user.id, email: user.email! },
  };
}

/**
 * For routes/actions with a stricter requirement than "is a member" —
 * e.g. Settings -> Billing, which per Permission_Matrix.md is owner-only.
 * Throws (caught by the nearest error boundary) rather than silently
 * proceeding — a permission gate that fails open is worse than one that
 * fails loud.
 */
export function assertOrgRole(context: OrgContext, allowed: OrgRole[]) {
  if (!allowed.includes(context.role)) {
    throw new Error("INSUFFICIENT_PERMISSIONS");
  }
}
