"use server";

import { redirect } from "next/navigation";

import { fail, ok, type AppResult } from "@/lib/errors";
import { createClient } from "@/lib/supabase/server";
import {
  loginSchema,
  requestPasswordResetSchema,
  resetPasswordSchema,
  signUpSchema,
  type LoginInput,
  type RequestPasswordResetInput,
  type ResetPasswordInput,
  type SignUpInput,
} from "@/lib/validators/auth";

function fieldErrorsFrom(issues: { path: (string | number)[]; message: string }[]) {
  const details: Record<string, string[]> = {};
  for (const issue of issues) {
    const key = String(issue.path[0] ?? "form");
    details[key] = [...(details[key] ?? []), issue.message];
  }
  return details;
}

export async function signUp(input: SignUpInput): Promise<AppResult<{ requiresVerification: boolean }>> {
  const parsed = signUpSchema.safeParse(input);
  if (!parsed.success) {
    return fail("VALIDATION_ERROR", "Please fix the errors below.", fieldErrorsFrom(parsed.error.issues));
  }

  const supabase = await createClient();
  const { data, error } = await supabase.auth.signUp({
    email: parsed.data.email,
    password: parsed.data.password,
    options: {
      data: { full_name: parsed.data.fullName },
      emailRedirectTo: `${process.env.NEXT_PUBLIC_SITE_URL}/auth/callback`,
    },
  });

  if (error) {
    if (error.message.toLowerCase().includes("already registered")) {
      return fail("EMAIL_TAKEN", "An account with this email already exists.");
    }
    return fail("SIGNUP_FAILED", "We couldn't create your account. Please try again.");
  }

  // Supabase returns a user with an empty identities array for an email
  // that already exists but hasn't been confirmed — surfaced distinctly
  // so the UI doesn't imply a brand-new account was created.
  const requiresVerification = !data.user?.email_confirmed_at;
  return ok({ requiresVerification });
}

export async function login(input: LoginInput): Promise<AppResult<{ redirectTo: string }>> {
  const parsed = loginSchema.safeParse(input);
  if (!parsed.success) {
    return fail("VALIDATION_ERROR", "Please fix the errors below.", fieldErrorsFrom(parsed.error.issues));
  }

  const supabase = await createClient();
  const { error } = await supabase.auth.signInWithPassword(parsed.data);

  if (error) {
    // Deliberately generic — per Authentication_Specification.md, never
    // reveal whether the email exists (avoids account enumeration).
    return fail("INVALID_CREDENTIALS", "Incorrect email or password.");
  }

  return ok({ redirectTo: "/" });
}

export async function signInWithOAuth(provider: "google" | "azure"): Promise<AppResult<{ url: string }>> {
  const supabase = await createClient();
  const { data, error } = await supabase.auth.signInWithOAuth({
    provider,
    options: { redirectTo: `${process.env.NEXT_PUBLIC_SITE_URL}/auth/callback` },
  });

  if (error || !data.url) {
    return fail("OAUTH_FAILED", "Sign-in was cancelled or failed. Please try again.");
  }
  return ok({ url: data.url });
}

export async function requestPasswordReset(
  input: RequestPasswordResetInput
): Promise<AppResult<{ sent: true }>> {
  const parsed = requestPasswordResetSchema.safeParse(input);
  if (!parsed.success) {
    return fail("VALIDATION_ERROR", "Enter a valid email address.", fieldErrorsFrom(parsed.error.issues));
  }

  const supabase = await createClient();
  await supabase.auth.resetPasswordForEmail(parsed.data.email, {
    redirectTo: `${process.env.NEXT_PUBLIC_SITE_URL}/reset-password`,
  });

  // Always return success regardless of whether the email exists —
  // prevents account enumeration via this endpoint (rate-limited
  // separately per Authentication_Specification.md Section 6).
  return ok({ sent: true });
}

export async function resetPassword(input: ResetPasswordInput): Promise<AppResult<{ done: true }>> {
  const parsed = resetPasswordSchema.safeParse(input);
  if (!parsed.success) {
    return fail("VALIDATION_ERROR", "Please fix the errors below.", fieldErrorsFrom(parsed.error.issues));
  }

  const supabase = await createClient();
  const { error } = await supabase.auth.updateUser({ password: parsed.data.password });

  if (error) {
    return fail("RESET_FAILED", "That reset link may have expired. Please request a new one.");
  }
  return ok({ done: true });
}

export async function logout() {
  const supabase = await createClient();
  await supabase.auth.signOut();
  redirect("/login");
}
