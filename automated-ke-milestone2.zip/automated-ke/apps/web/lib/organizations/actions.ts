"use server";

import { z } from "zod";

import { requireOrgAccess, assertOrgRole } from "@/lib/auth/guards";
import { fail, mapSupabaseError, ok, type AppResult } from "@/lib/errors";
import { createClient } from "@/lib/supabase/server";
import { createOrganizationSchema, type CreateOrganizationInput } from "@/lib/validators/organization";

export async function createOrganization(
  input: CreateOrganizationInput
): Promise<AppResult<{ orgSlug: string }>> {
  const parsed = createOrganizationSchema.safeParse(input);
  if (!parsed.success) {
    const details: Record<string, string[]> = {};
    for (const issue of parsed.error.issues) {
      const key = String(issue.path[0] ?? "form");
      details[key] = [...(details[key] ?? []), issue.message];
    }
    return fail("VALIDATION_ERROR", "Please fix the errors below.", details);
  }

  const supabase = await createClient();

  // Uses the normal RLS-scoped client, not the admin client — the RPC
  // function itself is SECURITY DEFINER and checks auth.uid() internally,
  // which is the correct trust boundary here (see API_Specification.md,
  // Section 2, "Architecture note").
  const { data, error } = await supabase.rpc("create_organization_with_owner", {
    p_name: parsed.data.name,
    p_industry: parsed.data.industry ?? null,
    p_country: parsed.data.country,
  });

  if (error) {
    if (error.message.includes("AUTH_REQUIRED")) {
      return fail("SESSION_EXPIRED", "Your session has expired. Please sign in again.");
    }
    if (error.message.includes("VALIDATION_ERROR")) {
      return fail("VALIDATION_ERROR", "Organization name is required.");
    }
    return fail(mapSupabaseError(error).code, mapSupabaseError(error).message);
  }

  const row = Array.isArray(data) ? data[0] : data;
  if (!row?.slug) {
    return fail("INTERNAL_ERROR", "Something went wrong. Please try again.");
  }

  return ok({ orgSlug: row.slug });
}

const updateOrganizationSchema = z.object({
  name: z.string().trim().min(2, "Organization name must be at least 2 characters").max(200),
});
export type UpdateOrganizationInput = z.infer<typeof updateOrganizationSchema>;

export async function updateOrganization(
  orgSlug: string,
  input: UpdateOrganizationInput
): Promise<AppResult<{ updated: true }>> {
  const parsed = updateOrganizationSchema.safeParse(input);
  if (!parsed.success) {
    return fail("VALIDATION_ERROR", "Organization name must be at least 2 characters.", {
      name: parsed.error.issues.map((i) => i.message),
    });
  }

  const context = await requireOrgAccess(orgSlug);
  // Mirrors the RLS policy exactly (owner/admin only) — see
  // RLS_Policy_Reference.md's organizations UPDATE row. Defense in
  // depth: RLS would reject this regardless of this check.
  assertOrgRole(context, ["owner", "admin"]);

  const supabase = await createClient();
  const { error } = await supabase
    .from("organizations")
    .update({ name: parsed.data.name.trim() })
    .eq("id", context.organization.id);

  if (error) {
    const mapped = mapSupabaseError(error);
    return fail(mapped.code, mapped.message);
  }

  return ok({ updated: true });
}
