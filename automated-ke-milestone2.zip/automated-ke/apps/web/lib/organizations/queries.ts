import "server-only";

import { createClient } from "@/lib/supabase/server";

export type UserOrgMembership = {
  organization_id: string;
  role: string;
  organizations: { id: string; name: string; slug: string } | null;
};

/**
 * Organizations the current authenticated user actively belongs to.
 * RLS-scoped (the "members can view fellow members of their orgs" +
 * "members can view their organizations" policies do the actual
 * filtering) — this query cannot return another user's memberships
 * regardless of what's passed in, since there's nothing to pass in: it's
 * always scoped to auth.uid() by the database itself.
 */
export async function getUserOrganizations(): Promise<UserOrgMembership[]> {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("organization_members")
    .select("organization_id, role, organizations(id, name, slug)")
    .eq("status", "active")
    .order("joined_at", { ascending: true });

  if (error || !data) return [];
  return data as unknown as UserOrgMembership[];
}
