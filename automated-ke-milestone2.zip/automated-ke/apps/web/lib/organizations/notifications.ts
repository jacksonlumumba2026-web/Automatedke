import "server-only";

import { createClient } from "@/lib/supabase/server";

export async function getUnreadNotificationCount(organizationId: string): Promise<number> {
  const supabase = await createClient();
  const { count } = await supabase
    .from("notifications")
    .select("id", { count: "exact", head: true })
    .eq("organization_id", organizationId)
    .is("read_at", null);

  return count ?? 0;
}
