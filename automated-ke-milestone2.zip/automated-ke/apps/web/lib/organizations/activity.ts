import "server-only";

import { createClient } from "@/lib/supabase/server";

export type AuditLogEntry = {
  id: string;
  action: string;
  entity_type: string;
  created_at: string;
};

/**
 * RLS ("owners and admins can view their org's audit log") means this
 * naturally returns an empty array for non-admin roles — no special-
 * casing needed here; the dashboard renders an EmptyState either way.
 */
export async function getRecentActivity(organizationId: string, limit = 8): Promise<AuditLogEntry[]> {
  const supabase = await createClient();
  const { data } = await supabase
    .from("audit_logs")
    .select("id, action, entity_type, created_at")
    .eq("organization_id", organizationId)
    .order("created_at", { ascending: false })
    .limit(limit);

  return data ?? [];
}
