/**
 * The one error shape used everywhere — Edge Functions, server actions,
 * client-caught exceptions. See Engineering_Standards.md, Part 1.
 */
export type AppError = {
  code: string;
  message: string;
  details?: Record<string, string[]> | null;
};

export type AppResult<T> = { data: T; error: null } | { data: null; error: AppError };

export function ok<T>(data: T): AppResult<T> {
  return { data, error: null };
}

export function fail(code: string, message: string, details?: AppError["details"]): AppResult<never> {
  return { data: null, error: { code, message, details: details ?? null } };
}

/**
 * Maps a raw Postgres/Supabase error to the standard shape. Deliberately
 * never passes the raw error message through for unrecognized codes —
 * per Engineering_Standards.md Section 1.4, a raw Postgres error never
 * reaches the client.
 */
export function mapSupabaseError(error: { code?: string; message: string }): AppError {
  switch (error.code) {
    case "23505": // unique_violation
      return { code: "CONFLICT", message: "That value is already in use." };
    case "42501": // insufficient_privilege (RLS denial)
      return { code: "INSUFFICIENT_PERMISSIONS", message: "You don't have permission to do that." };
    default:
      return { code: "INTERNAL_ERROR", message: "Something went wrong. Please try again." };
  }
}
