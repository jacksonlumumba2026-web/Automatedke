import { createBrowserClient } from "@supabase/ssr";

import type { Database } from "@automated-ke/types";

/**
 * Client for use in Client Components ("use client"). Uses the public
 * anon key — safe to expose, since RLS is the actual authorization
 * boundary (CLAUDE.md Rule 2), not this key's secrecy.
 */
export function createClient() {
  return createBrowserClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  );
}
