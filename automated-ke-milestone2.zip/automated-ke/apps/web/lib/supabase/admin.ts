import "server-only";

import { createClient as createSupabaseClient } from "@supabase/supabase-js";

import type { Database } from "@automated-ke/types";

/**
 * SERVICE-ROLE CLIENT — BYPASSES ROW LEVEL SECURITY ENTIRELY.
 *
 * `import "server-only"` at the top makes any accidental import of this
 * file from client-side code a BUILD ERROR, not just a lint warning —
 * defense in depth alongside the `no-restricted-imports` ESLint rule in
 * packages/config/eslint-preset.js.
 *
 * Valid uses (CLAUDE.md Rule 5):
 *   - Edge Functions performing controlled, transactional, multi-table
 *     operations where the acting "authorization" is the function's own
 *     logic, not row-level membership (e.g. create-organization, which
 *     runs before the user has any organization_members row to be
 *     RLS-checked against).
 *   - Trusted server-only maintenance/admin scripts.
 *
 * NEVER use this client to serve a normal authenticated request just
 * because it's more convenient than dealing with RLS — if a query needs
 * this client to succeed, that's a signal the RLS policy or the request
 * flow needs rethinking, not that this client is the fix.
 */
export function createAdminClient() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

  if (!url || !serviceRoleKey) {
    throw new Error(
      "createAdminClient() called without NEXT_PUBLIC_SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY configured."
    );
  }

  return createSupabaseClient<Database>(url, serviceRoleKey, {
    auth: {
      autoRefreshToken: false,
      persistSession: false,
    },
  });
}
