import { createServerClient, type CookieOptions } from "@supabase/ssr";
import { cookies } from "next/headers";

import type { Database } from "@automated-ke/types";

/**
 * Client for use in Server Components, Server Actions, and Route
 * Handlers. Reads the user's session from cookies — this is what makes
 * RLS-scoped queries run as the actual authenticated user server-side,
 * rather than as an anonymous/service role. Every "authoritative" data
 * access in the app (per CLAUDE.md Rule 2) should go through this, not
 * the admin client, unless the operation genuinely requires bypassing
 * RLS (see admin.ts).
 */
export async function createClient() {
  const cookieStore = await cookies();

  return createServerClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        get(name: string) {
          return cookieStore.get(name)?.value;
        },
        set(name: string, value: string, options: CookieOptions) {
          try {
            cookieStore.set({ name, value, ...options });
          } catch {
            // Called from a Server Component where cookies can't be set.
            // Safe to ignore IF middleware.ts is also refreshing the
            // session on every request (it is — see middleware.ts).
          }
        },
        remove(name: string, options: CookieOptions) {
          try {
            cookieStore.set({ name, value: "", ...options });
          } catch {
            // Same as above.
          }
        },
      },
    }
  );
}
