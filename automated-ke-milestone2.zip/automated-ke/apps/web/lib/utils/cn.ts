import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

/**
 * Merges Tailwind classes safely — later classes win over earlier
 * conflicting ones (e.g. cn("p-2", "p-4") -> "p-4"), which is what makes
 * components/ui primitives safely composable via a `className` prop
 * without producing conflicting utility classes. See Component_Library.md
 * Section "Component Build Standard", point 3.
 */
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}
