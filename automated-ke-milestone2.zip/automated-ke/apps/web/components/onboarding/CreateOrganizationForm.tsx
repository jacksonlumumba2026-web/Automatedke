"use client";

import { useRouter } from "next/navigation";
import { useState, type FormEvent } from "react";

import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import { Select } from "@/components/ui/Select";
import { createOrganization } from "@/lib/organizations/actions";
import { setPendingToast } from "@/lib/toast/pending";
import { INDUSTRY_OPTIONS } from "@/lib/validators/organization";

export function CreateOrganizationForm() {
  const router = useRouter();
  const [name, setName] = useState("");
  const [industry, setIndustry] = useState("retail");
  const [fieldErrors, setFieldErrors] = useState<Record<string, string[]>>({});
  const [formError, setFormError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setFormError(null);
    setFieldErrors({});
    setSubmitting(true);

    const result = await createOrganization({ name, industry, country: "KE" });

    if (result.error) {
      setFieldErrors(result.error.details ?? {});
      if (result.error.code !== "VALIDATION_ERROR") {
        setFormError(result.error.message);
      }
      setSubmitting(false);
      return;
    }

    setPendingToast(`${name.trim()} is ready to go.`, "success");
    router.push(`/${result.data.orgSlug}/dashboard`);
    router.refresh();
  }

  return (
    <form onSubmit={handleSubmit} noValidate className="flex flex-col gap-4">
      <Input
        label="Business name"
        required
        placeholder="e.g. Nakuru Hardware Ltd"
        value={name}
        onChange={(e) => setName(e.target.value)}
        error={fieldErrors.name?.[0]}
      />
      <Select
        label="Industry"
        options={INDUSTRY_OPTIONS}
        value={industry}
        onChange={(e) => setIndustry(e.target.value)}
        helperText="We'll set up your dashboard with the modules most relevant to your business."
      />
      {formError && (
        <p role="alert" className="text-sm text-danger">
          {formError}
        </p>
      )}
      <Button type="submit" size="lg" loading={submitting}>
        Create organization
      </Button>
    </form>
  );
}
