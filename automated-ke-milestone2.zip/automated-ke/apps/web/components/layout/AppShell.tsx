import type { ReactNode } from "react";

import { MobileNav } from "@/components/layout/MobileNav";
import { Sidebar } from "@/components/layout/Sidebar";
import { Topbar } from "@/components/layout/Topbar";
import { OrganizationProvider, type OrganizationContextValue } from "@/hooks/use-organization";
import { getUnreadNotificationCount } from "@/lib/organizations/notifications";
import { getUserOrganizations } from "@/lib/organizations/queries";

export async function AppShell({
  orgContext,
  userName,
  userEmail,
  children,
}: {
  orgContext: OrganizationContextValue;
  userName: string;
  userEmail: string;
  children: ReactNode;
}) {
  const [memberships, unreadCount] = await Promise.all([
    getUserOrganizations(),
    getUnreadNotificationCount(orgContext.organization.id),
  ]);

  return (
    <OrganizationProvider value={orgContext}>
      <div className="flex min-h-screen">
        <Sidebar />
        <div className="flex flex-1 flex-col">
          <Topbar memberships={memberships} unreadCount={unreadCount} userName={userName} userEmail={userEmail} />
          <main className="flex-1 p-4 pb-20 md:p-6 md:pb-6">{children}</main>
        </div>
        <MobileNav />
      </div>
    </OrganizationProvider>
  );
}
