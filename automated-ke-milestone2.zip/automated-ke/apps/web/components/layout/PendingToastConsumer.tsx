"use client";

import { usePathname } from "next/navigation";
import { useEffect } from "react";

import { useToast } from "@/components/ui/Toast";
import { takePendingToast } from "@/lib/toast/pending";

export function PendingToastConsumer() {
  const { toast } = useToast();
  const pathname = usePathname();

  useEffect(() => {
    const pending = takePendingToast();
    if (pending) {
      toast(pending.message, pending.variant);
    }
    // Re-checks on every navigation. This component lives in the root
    // layout, which App Router does NOT remount on client-side
    // navigation — a mount-only effect would miss every toast queued by
    // a router.push() (e.g. after creating an org or resetting a
    // password), which is the entire reason this component exists.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pathname]);

  return null;
}
