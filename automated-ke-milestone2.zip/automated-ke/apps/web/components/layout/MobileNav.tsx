"use client";

import Link from "next/link";

import { cn } from "@/lib/utils/cn";

import { useVisibleNavItems } from "./Sidebar";

export function MobileNav() {
  const visibleItems = useVisibleNavItems();

  return (
    <nav
      aria-label="Main navigation"
      className="fixed inset-x-0 bottom-0 z-10 flex border-t border-border bg-surface dark:border-border-dark dark:bg-surface-dark md:hidden"
    >
      {visibleItems.map((item) => (
        <Link
          key={item.key}
          href={item.href}
          aria-current={item.isActive ? "page" : undefined}
          className={cn(
            "flex flex-1 flex-col items-center gap-0.5 py-2 text-xs font-medium",
            item.isActive ? "text-primary dark:text-primary-dark" : "text-ink-secondary dark:text-ink-secondary-dark"
          )}
        >
          <span aria-hidden="true">{item.icon}</span>
          {item.label}
        </Link>
      ))}
    </nav>
  );
}
