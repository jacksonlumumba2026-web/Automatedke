"use client";

/**
 * Phase 1 scope only: unread count + list, in-app only. Per
 * Phase1_Architecture.md Step 8, email/SMS/WhatsApp delivery channels
 * are Phase 5 work — this component deliberately does not attempt them.
 */
export function NotificationBell({ unreadCount }: { unreadCount: number }) {
  return (
    <button
      type="button"
      aria-label={unreadCount > 0 ? `Notifications, ${unreadCount} unread` : "Notifications"}
      className="relative rounded-full p-2 text-ink-secondary hover:bg-background hover:text-ink-primary focus-visible:outline-none dark:text-ink-secondary-dark dark:hover:bg-background-dark dark:hover:text-ink-primary-dark"
    >
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} aria-hidden="true">
        <path d="M18 8a6 6 0 10-12 0c0 7-3 9-3 9h18s-3-2-3-9" />
        <path d="M13.73 21a2 2 0 01-3.46 0" />
      </svg>
      {unreadCount > 0 && (
        <span
          aria-hidden="true"
          className="absolute right-1 top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-danger px-1 text-[10px] font-medium text-white"
        >
          {unreadCount > 9 ? "9+" : unreadCount}
        </span>
      )}
    </button>
  );
}
