"use client";

import Link from "next/link";
import { useState, useRef, useEffect } from "react";

import { Avatar } from "@/components/ui";
import { useOrganization } from "@/hooks/use-organization";
import type { UserOrgMembership } from "@/lib/organizations/queries";

/**
 * Renders nothing if the user belongs to only one organization — per
 * Component_Library.md: "renders only when the current user has ...
 * more than one org; otherwise renders nothing (no empty dropdown for
 * the common single-org case)."
 */
export function OrgSwitcher({ memberships }: { memberships: UserOrgMembership[] }) {
  const { organization } = useOrganization();
  const [open, setOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  if (memberships.length <= 1) return null;

  return (
    <div ref={containerRef} className="relative">
      <button
        type="button"
        aria-haspopup="menu"
        aria-expanded={open}
        onClick={() => setOpen((v) => !v)}
        className="flex items-center gap-2 rounded px-2 py-1.5 text-sm font-medium text-ink-primary hover:bg-background focus-visible:outline-none dark:text-ink-primary-dark dark:hover:bg-background-dark"
      >
        <Avatar name={organization.name} size="sm" />
        <span className="max-w-[140px] truncate">{organization.name}</span>
        <ChevronIcon />
      </button>
      {open && (
        <ul
          role="menu"
          className="absolute left-0 z-10 mt-1 w-56 rounded-lg border border-border bg-surface py-1 shadow-lg dark:border-border-dark dark:bg-surface-dark"
        >
          {memberships.map((m) =>
            m.organizations ? (
              <li key={m.organization_id} role="none">
                <Link
                  role="menuitem"
                  href={`/${m.organizations.slug}/dashboard`}
                  className="block px-3 py-2 text-sm text-ink-primary hover:bg-background dark:text-ink-primary-dark dark:hover:bg-background-dark"
                  onClick={() => setOpen(false)}
                >
                  {m.organizations.name}
                </Link>
              </li>
            ) : null
          )}
        </ul>
      )}
    </div>
  );
}

function ChevronIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} aria-hidden="true">
      <path d="M6 9l6 6 6-6" />
    </svg>
  );
}
