"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import type { ReactNode } from "react";

import { cn } from "@/lib/utils/cn";
import { useOrganization } from "@/hooks/use-organization";
import { usePermissions } from "@/hooks/use-permissions";

type NavItem = {
  key: string;
  label: string;
  href: (orgSlug: string) => string;
  icon: ReactNode;
  requiresModule?: string;
  requiresPermission?: "canManageTeam" | "canManageBilling";
};

const NAV_ITEMS: NavItem[] = [
  { key: "dashboard", label: "Dashboard", href: (slug) => `/${slug}/dashboard`, icon: <DashboardIcon /> },
  {
    key: "settings",
    label: "Settings",
    href: (slug) => `/${slug}/settings`,
    icon: <SettingsIcon />,
  },
];

export function useVisibleNavItems(): (NavItem & { href: string; isActive: boolean })[] {
  const { organization } = useOrganization();
  const permissions = usePermissions();
  const pathname = usePathname();

  return NAV_ITEMS.filter((item) => {
    if (item.requiresModule && !organization.enabled_modules.includes(item.requiresModule)) {
      return false;
    }
    if (item.requiresPermission && !permissions[item.requiresPermission]) {
      return false;
    }
    return true;
  }).map((item) => {
    const href = item.href(organization.slug);
    return { ...item, href, isActive: pathname === href || pathname.startsWith(`${href}/`) };
  });
}

export function Sidebar() {
  const visibleItems = useVisibleNavItems();

  return (
    <nav
      aria-label="Main navigation"
      className="hidden w-60 flex-col border-r border-border bg-surface p-4 dark:border-border-dark dark:bg-surface-dark md:flex"
    >
      <ul className="flex flex-col gap-1">
        {visibleItems.map((item) => (
          <li key={item.key}>
            <Link
              href={item.href}
              aria-current={item.isActive ? "page" : undefined}
              className={cn(
                "flex items-center gap-3 rounded px-3 py-2 text-sm font-medium transition-colors",
                item.isActive
                  ? "bg-primary/10 text-primary dark:bg-primary/20 dark:text-primary-dark"
                  : "text-ink-secondary hover:bg-background hover:text-ink-primary dark:text-ink-secondary-dark dark:hover:bg-background-dark dark:hover:text-ink-primary-dark"
              )}
            >
              <span aria-hidden="true">{item.icon}</span>
              {item.label}
            </Link>
          </li>
        ))}
      </ul>
    </nav>
  );
}

// Minimal inline icons — no icon library dependency for Phase 1's small
// nav set; revisit with lucide-react once more modules (and thus more
// icons) ship in Phase 2+.
function iconProps() {
  return { width: 18, height: 18, viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: 2 } as const;
}
function DashboardIcon() {
  return (
    <svg {...iconProps()}>
      <rect x="3" y="3" width="7" height="9" rx="1" />
      <rect x="14" y="3" width="7" height="5" rx="1" />
      <rect x="14" y="12" width="7" height="9" rx="1" />
      <rect x="3" y="16" width="7" height="5" rx="1" />
    </svg>
  );
}
function SettingsIcon() {
  return (
    <svg {...iconProps()}>
      <circle cx="12" cy="12" r="3" />
      <path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 11-2.83 2.83l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09a1.65 1.65 0 00-1-1.51 1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 11-2.83-2.83l.06-.06a1.65 1.65 0 00.33-1.82 1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09a1.65 1.65 0 001.51-1 1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 112.83-2.83l.06.06a1.65 1.65 0 001.82.33H9a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 112.83 2.83l-.06.06a1.65 1.65 0 00-.33 1.82V9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z" />
    </svg>
  );
}
