"use client";

import { useEffect, useRef, useState } from "react";

import { Avatar } from "@/components/ui";
import { logout } from "@/lib/auth/actions";

export function UserMenu({ userName, userEmail }: { userName: string; userEmail: string }) {
  const [open, setOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <div ref={containerRef} className="relative">
      <button
        type="button"
        aria-haspopup="menu"
        aria-expanded={open}
        aria-label={`Account menu for ${userName}`}
        onClick={() => setOpen((v) => !v)}
        className="rounded-full focus-visible:outline-none"
      >
        <Avatar name={userName} size="md" />
      </button>
      {open && (
        <div
          role="menu"
          className="absolute right-0 z-10 mt-2 w-56 rounded-lg border border-border bg-surface py-1 shadow-lg dark:border-border-dark dark:bg-surface-dark"
        >
          <div className="px-3 py-2">
            <p className="truncate text-sm font-medium text-ink-primary dark:text-ink-primary-dark">{userName}</p>
            <p className="truncate text-xs text-ink-secondary dark:text-ink-secondary-dark">{userEmail}</p>
          </div>
          <div className="my-1 h-px bg-border dark:bg-border-dark" />
          <form action={logout}>
            <button
              type="submit"
              role="menuitem"
              className="block w-full px-3 py-2 text-left text-sm text-danger hover:bg-background dark:hover:bg-background-dark"
            >
              Sign out
            </button>
          </form>
        </div>
      )}
    </div>
  );
}
