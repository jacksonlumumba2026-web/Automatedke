"use client";

import { useId, useState, type ReactNode } from "react";

import { cn } from "@/lib/utils/cn";

export type TabsProps = {
  tabs: { key: string; label: string; content: ReactNode }[];
  defaultTab?: string;
};

export function Tabs({ tabs, defaultTab }: TabsProps) {
  const [activeKey, setActiveKey] = useState(defaultTab ?? tabs[0]?.key);
  const idBase = useId();

  return (
    <div>
      <div role="tablist" aria-label="Settings sections" className="flex gap-1 border-b border-border dark:border-border-dark">
        {tabs.map((tab) => {
          const isActive = tab.key === activeKey;
          return (
            <button
              key={tab.key}
              type="button"
              role="tab"
              id={`${idBase}-tab-${tab.key}`}
              aria-selected={isActive}
              aria-controls={`${idBase}-panel-${tab.key}`}
              tabIndex={isActive ? 0 : -1}
              onClick={() => setActiveKey(tab.key)}
              onKeyDown={(e) => {
                if (e.key !== "ArrowRight" && e.key !== "ArrowLeft") return;
                const index = tabs.findIndex((t) => t.key === tab.key);
                const nextIndex =
                  e.key === "ArrowRight" ? (index + 1) % tabs.length : (index - 1 + tabs.length) % tabs.length;
                setActiveKey(tabs[nextIndex]!.key);
              }}
              className={cn(
                "-mb-px border-b-2 px-4 py-2 text-sm font-medium focus-visible:outline-none",
                isActive
                  ? "border-primary text-primary dark:border-primary-dark dark:text-primary-dark"
                  : "border-transparent text-ink-secondary hover:text-ink-primary dark:text-ink-secondary-dark dark:hover:text-ink-primary-dark"
              )}
            >
              {tab.label}
            </button>
          );
        })}
      </div>
      {tabs.map((tab) => (
        <div
          key={tab.key}
          role="tabpanel"
          id={`${idBase}-panel-${tab.key}`}
          aria-labelledby={`${idBase}-tab-${tab.key}`}
          hidden={tab.key !== activeKey}
          className="pt-6"
        >
          {tab.key === activeKey && tab.content}
        </div>
      ))}
    </div>
  );
}
