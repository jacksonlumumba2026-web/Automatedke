"use client";

import { useState, type ReactNode } from "react";

import { Skeleton } from "./index";

export type Column<T> = {
  key: string;
  header: string;
  sortable?: boolean;
  render?: (row: T) => ReactNode;
  width?: string;
};

export type TableProps<T> = {
  columns: Column<T>[];
  data: T[];
  loading?: boolean;
  emptyState?: ReactNode;
  onSort?: (key: string, direction: "asc" | "desc") => void;
  pagination?: { page: number; pageSize: number; total: number; onPageChange: (page: number) => void };
  rowKey: (row: T) => string;
};

/**
 * Every future domain module's list view (customers, products, invoices,
 * employees) is this same component with different columns and a
 * different data source — see Component_Library.md's rationale for why
 * this is deliberately generic rather than built per-feature.
 */
export function Table<T>({ columns, data, loading, emptyState, onSort, pagination, rowKey }: TableProps<T>) {
  const [sortState, setSortState] = useState<{ key: string; direction: "asc" | "desc" } | null>(null);

  function handleSort(key: string) {
    if (!onSort) return;
    const direction: "asc" | "desc" = sortState?.key === key && sortState.direction === "asc" ? "desc" : "asc";
    setSortState({ key, direction });
    onSort(key, direction);
  }

  if (loading) {
    return (
      <div className="overflow-hidden rounded-lg border border-border dark:border-border-dark">
        <Skeleton variant="table-row" count={columns.length} />
      </div>
    );
  }

  if (data.length === 0) {
    return emptyState ?? null;
  }

  return (
    <div className="overflow-x-auto rounded-lg border border-border dark:border-border-dark">
      <table className="w-full text-left text-sm">
        <thead className="border-b border-border bg-background dark:border-border-dark dark:bg-background-dark">
          <tr>
            {columns.map((col) => (
              <th
                key={col.key}
                scope="col"
                style={col.width ? { width: col.width } : undefined}
                className="px-4 py-3 font-medium text-ink-secondary dark:text-ink-secondary-dark"
                aria-sort={
                  col.sortable && sortState?.key === col.key
                    ? sortState.direction === "asc"
                      ? "ascending"
                      : "descending"
                    : undefined
                }
              >
                {col.sortable ? (
                  <button
                    type="button"
                    onClick={() => handleSort(col.key)}
                    className="flex items-center gap-1 focus-visible:outline-none"
                  >
                    {col.header}
                    <SortIcon
                      direction={sortState?.key === col.key ? sortState.direction : undefined}
                    />
                  </button>
                ) : (
                  col.header
                )}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-border dark:divide-border-dark">
          {data.map((row) => (
            <tr key={rowKey(row)} className="hover:bg-background dark:hover:bg-background-dark">
              {columns.map((col) => (
                <td key={col.key} className="px-4 py-3 text-ink-primary dark:text-ink-primary-dark">
                  {col.render ? col.render(row) : String((row as Record<string, unknown>)[col.key] ?? "")}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
      {pagination && <TablePagination {...pagination} />}
    </div>
  );
}

function SortIcon({ direction }: { direction?: "asc" | "desc" }) {
  return (
    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} aria-hidden="true">
      {direction === "asc" ? <path d="M6 15l6-6 6 6" /> : direction === "desc" ? <path d="M6 9l6 6 6-6" /> : (
        <>
          <path d="M8 9l4-4 4 4" />
          <path d="M8 15l4 4 4-4" />
        </>
      )}
    </svg>
  );
}

function TablePagination({
  page,
  pageSize,
  total,
  onPageChange,
}: {
  page: number;
  pageSize: number;
  total: number;
  onPageChange: (page: number) => void;
}) {
  const totalPages = Math.max(1, Math.ceil(total / pageSize));

  return (
    <div className="flex items-center justify-between border-t border-border px-4 py-3 text-sm text-ink-secondary dark:border-border-dark dark:text-ink-secondary-dark">
      <span>
        Page {page} of {totalPages}
      </span>
      <div className="flex gap-2">
        <button
          type="button"
          disabled={page <= 1}
          onClick={() => onPageChange(page - 1)}
          className="rounded px-2 py-1 hover:bg-background disabled:opacity-40 disabled:cursor-not-allowed dark:hover:bg-background-dark"
        >
          Previous
        </button>
        <button
          type="button"
          disabled={page >= totalPages}
          onClick={() => onPageChange(page + 1)}
          className="rounded px-2 py-1 hover:bg-background disabled:opacity-40 disabled:cursor-not-allowed dark:hover:bg-background-dark"
        >
          Next
        </button>
      </div>
    </div>
  );
}
