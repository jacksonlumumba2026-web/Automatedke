import type { HTMLAttributes, ReactNode } from "react";

import { cn } from "@/lib/utils/cn";

type CardProps = { children: ReactNode } & HTMLAttributes<HTMLDivElement>;

function Card({ children, className, ...props }: CardProps) {
  return (
    <div
      className={cn(
        "rounded-lg border border-border bg-surface dark:border-border-dark dark:bg-surface-dark",
        className
      )}
      {...props}
    >
      {children}
    </div>
  );
}

function CardHeader({ children, className, ...props }: CardProps) {
  return (
    <div
      className={cn("border-b border-border px-6 py-4 font-semibold text-ink-primary dark:border-border-dark dark:text-ink-primary-dark", className)}
      {...props}
    >
      {children}
    </div>
  );
}

function CardBody({ children, className, ...props }: CardProps) {
  return (
    <div className={cn("p-6", className)} {...props}>
      {children}
    </div>
  );
}

function CardFooter({ children, className, ...props }: CardProps) {
  return (
    <div className={cn("border-t border-border px-6 py-4 dark:border-border-dark", className)} {...props}>
      {children}
    </div>
  );
}

Card.Header = CardHeader;
Card.Body = CardBody;
Card.Footer = CardFooter;

export { Card };
