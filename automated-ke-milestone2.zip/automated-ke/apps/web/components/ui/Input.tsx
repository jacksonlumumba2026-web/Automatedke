import { forwardRef, useId, type InputHTMLAttributes } from "react";

import { cn } from "@/lib/utils/cn";

export type InputProps = {
  label: string;
  helperText?: string;
  error?: string;
} & InputHTMLAttributes<HTMLInputElement>;

/**
 * `label` is required (not optional) — Component_Library.md is explicit
 * that this primitive never ships a placeholder-as-label pattern.
 */
export const Input = forwardRef<HTMLInputElement, InputProps>(
  ({ label, helperText, error, required, id, className, ...props }, ref) => {
    const generatedId = useId();
    const inputId = id ?? generatedId;
    const helperId = `${inputId}-helper`;
    const errorId = `${inputId}-error`;

    return (
      <div className="flex flex-col gap-1.5">
        <label htmlFor={inputId} className="text-sm font-medium text-ink-primary dark:text-ink-primary-dark">
          {label}
          {required && <span aria-hidden="true" className="text-danger ml-0.5">*</span>}
        </label>
        <input
          ref={ref}
          id={inputId}
          required={required}
          aria-invalid={Boolean(error) || undefined}
          aria-describedby={error ? errorId : helperText ? helperId : undefined}
          className={cn(
            "h-10 rounded border border-border bg-surface px-3 text-sm text-ink-primary",
            "dark:bg-surface-dark dark:border-border-dark dark:text-ink-primary-dark",
            "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:border-primary",
            "disabled:opacity-50 disabled:cursor-not-allowed",
            error && "border-danger focus-visible:ring-danger",
            className
          )}
          {...props}
        />
        {error ? (
          <p id={errorId} className="text-sm text-danger" role="alert">
            {error}
          </p>
        ) : helperText ? (
          <p id={helperId} className="text-sm text-ink-secondary dark:text-ink-secondary-dark">
            {helperText}
          </p>
        ) : null}
      </div>
    );
  }
);
Input.displayName = "Input";
