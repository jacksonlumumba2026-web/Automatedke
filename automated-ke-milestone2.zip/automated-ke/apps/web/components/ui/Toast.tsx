"use client";

import { createContext, useCallback, useContext, useRef, useState, type ReactNode } from "react";

import { cn } from "@/lib/utils/cn";

export type ToastVariant = "success" | "error" | "info" | "warning";

type ToastItem = {
  id: string;
  message: string;
  variant: ToastVariant;
  duration: number;
};

type ToastContextValue = {
  toast: (message: string, variant?: ToastVariant, options?: { duration?: number }) => void;
};

const ToastContext = createContext<ToastContextValue | null>(null);

const DEFAULT_DURATION = 5000;

const variantStyles: Record<ToastVariant, string> = {
  success: "border-accent/30 bg-surface text-accent-strong dark:bg-surface-dark dark:border-accent/40 dark:text-accent-dark",
  error: "border-danger/30 bg-surface text-danger dark:bg-surface-dark dark:border-danger/40 dark:text-danger-dark",
  info: "border-primary/30 bg-surface text-primary dark:bg-surface-dark dark:border-primary/40 dark:text-primary-dark",
  warning: "border-warning/30 bg-surface text-warning-strong dark:bg-surface-dark dark:border-warning/40 dark:text-warning-dark",
};

/**
 * Mount once, at the root layout. Every mutation in the app fires
 * exactly one toast — success or error, never both, never silent — per
 * Component_Library.md's <Toast> spec.
 */
export function ToastProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<ToastItem[]>([]);
  const timers = useRef<Map<string, ReturnType<typeof setTimeout>>>(new Map());

  const dismiss = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
    const timer = timers.current.get(id);
    if (timer) {
      clearTimeout(timer);
      timers.current.delete(id);
    }
  }, []);

  const scheduleDismiss = useCallback(
    (id: string, duration: number) => {
      const timer = setTimeout(() => dismiss(id), duration);
      timers.current.set(id, timer);
    },
    [dismiss]
  );

  const toast = useCallback<ToastContextValue["toast"]>(
    (message, variant = "info", options) => {
      const id = crypto.randomUUID();
      const duration = options?.duration ?? DEFAULT_DURATION;
      setToasts((prev) => [...prev, { id, message, variant, duration }]);
      scheduleDismiss(id, duration);
    },
    [scheduleDismiss]
  );

  function handlePause(id: string) {
    const timer = timers.current.get(id);
    if (timer) clearTimeout(timer);
  }

  function handleResume(id: string, duration: number) {
    scheduleDismiss(id, duration);
  }

  return (
    <ToastContext.Provider value={{ toast }}>
      {children}
      <div
        className="pointer-events-none fixed bottom-4 right-4 z-50 flex flex-col gap-2 sm:bottom-6 sm:right-6"
        aria-live="polite"
      >
        {toasts.map((t) => (
          <div
            key={t.id}
            role={t.variant === "error" ? "alert" : "status"}
            onMouseEnter={() => handlePause(t.id)}
            onMouseLeave={() => handleResume(t.id, t.duration)}
            className={cn(
              "pointer-events-auto flex max-w-sm items-start gap-3 rounded-lg border px-4 py-3 text-sm shadow-lg",
              variantStyles[t.variant]
            )}
          >
            <span className="flex-1">{t.message}</span>
            <button
              type="button"
              aria-label="Dismiss notification"
              onClick={() => dismiss(t.id)}
              className="text-current opacity-60 hover:opacity-100 focus-visible:outline-none"
            >
              ×
            </button>
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  );
}

export function useToast(): ToastContextValue {
  const ctx = useContext(ToastContext);
  if (!ctx) {
    throw new Error("useToast() must be used within a ToastProvider");
  }
  return ctx;
}
