import type { ReactNode } from "react";

import { cn } from "@/lib/utils/cn";
import { Button } from "./Button";

// ---------------------------------------------------------------------------
// Badge
// ---------------------------------------------------------------------------
type BadgeVariant = "default" | "success" | "warning" | "danger" | "info";

const badgeStyles: Record<BadgeVariant, string> = {
  default: "bg-background text-ink-secondary dark:bg-surface-dark dark:text-ink-secondary-dark",
  success: "bg-accent/10 text-accent-strong dark:bg-accent/20 dark:text-accent-dark",
  warning: "bg-warning/10 text-warning-strong dark:bg-warning/20 dark:text-warning-dark",
  danger: "bg-danger/10 text-danger dark:bg-danger/20 dark:text-danger-dark",
  info: "bg-primary/10 text-primary dark:bg-primary/20 dark:text-primary-dark",
};

export function Badge({ variant = "default", children }: { variant?: BadgeVariant; children: ReactNode }) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium",
        badgeStyles[variant]
      )}
    >
      {children}
    </span>
  );
}

// ---------------------------------------------------------------------------
// Avatar
// ---------------------------------------------------------------------------
type AvatarSize = "sm" | "md" | "lg";
const avatarSizeStyles: Record<AvatarSize, string> = {
  sm: "h-6 w-6 text-xs",
  md: "h-9 w-9 text-sm",
  lg: "h-12 w-12 text-base",
};

function initialsFrom(name: string) {
  const parts = name.trim().split(/\s+/);
  const initials = parts.slice(0, 2).map((p) => p[0]?.toUpperCase() ?? "");
  return initials.join("") || "?";
}

export function Avatar({ src, name, size = "md" }: { src?: string | null; name: string; size?: AvatarSize }) {
  if (src) {
    // eslint-disable-next-line @next/next/no-img-element -- small avatar images, next/image overhead isn't worth it here
    return (
      <img
        src={src}
        alt={name}
        className={cn("rounded-full object-cover", avatarSizeStyles[size])}
      />
    );
  }
  return (
    <div
      role="img"
      aria-label={name}
      className={cn(
        "flex items-center justify-center rounded-full bg-primary/10 font-medium text-primary dark:bg-primary/20 dark:text-primary-dark",
        avatarSizeStyles[size]
      )}
    >
      {initialsFrom(name)}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Skeleton
// ---------------------------------------------------------------------------
type SkeletonVariant = "text" | "card" | "table-row" | "stat-card";

export function Skeleton({ variant, count = 1 }: { variant: SkeletonVariant; count?: number }) {
  const base = "animate-pulse rounded bg-border dark:bg-border-dark";
  const items = Array.from({ length: count });

  if (variant === "text") {
    return (
      <div className="flex flex-col gap-2">
        {items.map((_, i) => (
          <div key={i} className={cn(base, "h-4 w-full")} />
        ))}
      </div>
    );
  }
  if (variant === "card") {
    return <div className={cn(base, "h-40 w-full")} />;
  }
  if (variant === "stat-card") {
    return (
      <div className="rounded-lg border border-border p-6 dark:border-border-dark">
        <div className={cn(base, "h-4 w-24 mb-3")} />
        <div className={cn(base, "h-8 w-16")} />
      </div>
    );
  }
  // table-row
  return (
    <div className="flex gap-4 py-3">
      {items.map((_, i) => (
        <div key={i} className={cn(base, "h-4 flex-1")} />
      ))}
    </div>
  );
}

// ---------------------------------------------------------------------------
// EmptyState
// ---------------------------------------------------------------------------
export function EmptyState({
  icon,
  title,
  description,
  action,
}: {
  icon?: ReactNode;
  title: string;
  description?: string;
  action?: { label: string; onClick: () => void };
}) {
  return (
    <div className="flex flex-col items-center justify-center gap-2 rounded-lg border border-dashed border-border px-6 py-12 text-center dark:border-border-dark">
      {icon && <div className="mb-2 text-ink-secondary dark:text-ink-secondary-dark">{icon}</div>}
      <p className="font-medium text-ink-primary dark:text-ink-primary-dark">{title}</p>
      {description && (
        <p className="max-w-sm text-sm text-ink-secondary dark:text-ink-secondary-dark">{description}</p>
      )}
      {action && (
        <Button size="sm" variant="outline" className="mt-2" onClick={action.onClick}>
          {action.label}
        </Button>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// StatCard
// ---------------------------------------------------------------------------
export function StatCard({
  label,
  value,
  delta,
  icon,
  loading,
  invertColor = false,
}: {
  label: string;
  value: string | number;
  delta?: { value: number; direction: "up" | "down"; period: string };
  icon?: ReactNode;
  loading?: boolean;
  invertColor?: boolean;
}) {
  if (loading) return <Skeleton variant="stat-card" />;

  const isPositive = delta && (invertColor ? delta.direction === "down" : delta.direction === "up");

  return (
    <div className="rounded-lg border border-border bg-surface p-6 dark:border-border-dark dark:bg-surface-dark">
      <div className="flex items-center justify-between">
        <p className="text-sm text-ink-secondary dark:text-ink-secondary-dark">{label}</p>
        {icon && <div className="text-ink-secondary dark:text-ink-secondary-dark">{icon}</div>}
      </div>
      <p className="mt-2 text-2xl font-semibold text-ink-primary dark:text-ink-primary-dark">{value}</p>
      {delta && (
        <p className={cn("mt-1 text-sm", isPositive ? "text-accent-strong" : "text-danger")}>
          {delta.direction === "up" ? "↑" : "↓"} {Math.abs(delta.value)}% {delta.period}
        </p>
      )}
    </div>
  );
}
