import { forwardRef, useId, type SelectHTMLAttributes } from "react";

import { cn } from "@/lib/utils/cn";

export type SelectOption = { value: string; label: string; disabled?: boolean };

export type SelectProps = {
  label: string;
  options: SelectOption[];
  error?: string;
  helperText?: string;
} & Omit<SelectHTMLAttributes<HTMLSelectElement>, "children">;

export const Select = forwardRef<HTMLSelectElement, SelectProps>(
  ({ label, options, error, helperText, required, id, className, ...props }, ref) => {
    const generatedId = useId();
    const selectId = id ?? generatedId;

    return (
      <div className="flex flex-col gap-1.5">
        <label htmlFor={selectId} className="text-sm font-medium text-ink-primary dark:text-ink-primary-dark">
          {label}
          {required && <span aria-hidden="true" className="text-danger ml-0.5">*</span>}
        </label>
        <select
          ref={ref}
          id={selectId}
          required={required}
          aria-invalid={Boolean(error) || undefined}
          className={cn(
            "h-10 rounded border border-border bg-surface px-3 text-sm text-ink-primary",
            "dark:bg-surface-dark dark:border-border-dark dark:text-ink-primary-dark",
            "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:border-primary",
            error && "border-danger focus-visible:ring-danger",
            className
          )}
          {...props}
        >
          {options.map((opt) => (
            <option key={opt.value} value={opt.value} disabled={opt.disabled}>
              {opt.label}
            </option>
          ))}
        </select>
        {error ? (
          <p className="text-sm text-danger" role="alert">
            {error}
          </p>
        ) : helperText ? (
          <p className="text-sm text-ink-secondary dark:text-ink-secondary-dark">{helperText}</p>
        ) : null}
      </div>
    );
  }
);
Select.displayName = "Select";
