"use client";

import { useRouter } from "next/navigation";
import { useState, type FormEvent } from "react";

import { Button } from "@/components/ui/Button";
import { Card } from "@/components/ui/Card";
import { Input } from "@/components/ui/Input";
import { useToast } from "@/components/ui/Toast";
import { updateOrganization } from "@/lib/organizations/actions";

export function OrganizationTab({
  orgSlug,
  initialName,
  canEdit,
}: {
  orgSlug: string;
  initialName: string;
  canEdit: boolean;
}) {
  const router = useRouter();
  const { toast } = useToast();
  const [name, setName] = useState(initialName);
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setSubmitting(true);

    const result = await updateOrganization(orgSlug, { name });

    setSubmitting(false);
    if (result.error) {
      setError(result.error.message);
      return;
    }

    toast("Organization details updated.", "success");
    router.refresh();
  }

  return (
    <Card>
      <Card.Header>Organization details</Card.Header>
      <Card.Body>
        <form onSubmit={handleSubmit} noValidate className="flex max-w-md flex-col gap-4">
          <Input
            label="Organization name"
            required
            disabled={!canEdit}
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
          {error && (
            <p role="alert" className="text-sm text-danger">
              {error}
            </p>
          )}
          {canEdit && (
            <div>
              <Button type="submit" loading={submitting}>
                Save changes
              </Button>
            </div>
          )}
        </form>
      </Card.Body>
    </Card>
  );
}
