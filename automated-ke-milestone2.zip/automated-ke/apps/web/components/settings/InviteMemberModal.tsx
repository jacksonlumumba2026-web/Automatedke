"use client";

import { useState, type FormEvent } from "react";

import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import { Modal } from "@/components/ui/Modal";
import { Select } from "@/components/ui/Select";
import { useToast } from "@/components/ui/Toast";
import { sendInvitation } from "@/lib/invitations/actions";
import { ORG_ROLES } from "@/lib/rbac/constants";

const INVITABLE_ROLE_OPTIONS = ORG_ROLES.filter((r) => r.value !== "owner" && r.value !== "custom").map((r) => ({
  value: r.value,
  label: r.label,
}));

export function InviteMemberModal({
  orgSlug,
  open,
  onClose,
  onInvited,
}: {
  orgSlug: string;
  open: boolean;
  onClose: () => void;
  onInvited: () => void;
}) {
  const { toast } = useToast();
  const [email, setEmail] = useState("");
  const [role, setRole] = useState("read_only");
  const [fieldErrors, setFieldErrors] = useState<Record<string, string[]>>({});
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setFieldErrors({});
    setSubmitting(true);

    const result = await sendInvitation(orgSlug, { email, role });

    setSubmitting(false);

    if (result.error) {
      setFieldErrors(result.error.details ?? {});
      if (result.error.code !== "VALIDATION_ERROR") {
        toast(result.error.message, "error");
      }
      return;
    }

    toast(`Invitation sent to ${email}.`, "success");
    setEmail("");
    setRole("read_only");
    onInvited();
    onClose();
  }

  return (
    <Modal open={open} onClose={onClose} title="Invite a team member" description="They'll get a link to join this organization.">
      <form onSubmit={handleSubmit} noValidate className="flex flex-col gap-4">
        <Input
          label="Email"
          type="email"
          required
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          error={fieldErrors.email?.[0]}
        />
        <Select
          label="Role"
          options={INVITABLE_ROLE_OPTIONS}
          value={role}
          onChange={(e) => setRole(e.target.value)}
          error={fieldErrors.role?.[0]}
        />
        <div className="flex justify-end gap-3 pt-2">
          <Button type="button" variant="secondary" onClick={onClose}>
            Cancel
          </Button>
          <Button type="submit" loading={submitting}>
            Send invitation
          </Button>
        </div>
      </form>
    </Modal>
  );
}
