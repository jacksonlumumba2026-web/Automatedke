"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";

import { Badge, EmptyState } from "@/components/ui";
import { Button } from "@/components/ui/Button";
import { Table, type Column } from "@/components/ui/Table";
import { useToast } from "@/components/ui/Toast";
import { revokeInvitation } from "@/lib/invitations/actions";
import type { PendingInvitation, TeamMember } from "@/lib/invitations/queries";
import { statusToBadgeVariant } from "@/lib/rbac/constants";

import { InviteMemberModal } from "./InviteMemberModal";

export function TeamTab({
  orgSlug,
  members,
  invitations,
  canManageTeam,
}: {
  orgSlug: string;
  members: TeamMember[];
  invitations: PendingInvitation[];
  canManageTeam: boolean;
}) {
  const router = useRouter();
  const { toast } = useToast();
  const [inviteOpen, setInviteOpen] = useState(false);
  const [revokingId, setRevokingId] = useState<string | null>(null);

  async function handleRevoke(id: string) {
    setRevokingId(id);
    const result = await revokeInvitation(orgSlug, id);
    setRevokingId(null);
    if (result.error) {
      toast(result.error.message, "error");
      return;
    }
    toast("Invitation revoked.", "success");
    router.refresh();
  }

  const memberColumns: Column<TeamMember>[] = [
    { key: "name", header: "Name", render: (m) => m.users?.full_name || "—" },
    {
      key: "role",
      header: "Role",
      render: (m) => <span className="capitalize">{m.role.replace("_", " ")}</span>,
    },
    {
      key: "status",
      header: "Status",
      render: (m) => <Badge variant={statusToBadgeVariant(m.status)}>{m.status}</Badge>,
    },
  ];

  const invitationColumns: Column<PendingInvitation>[] = [
    { key: "email", header: "Email" },
    { key: "role", header: "Role", render: (i) => <span className="capitalize">{i.role.replace("_", " ")}</span> },
    { key: "expires_at", header: "Expires", render: (i) => new Date(i.expires_at).toLocaleDateString() },
    ...(canManageTeam
      ? [
          {
            key: "actions",
            header: "",
            render: (i: PendingInvitation) => (
              <Button
                size="sm"
                variant="ghost"
                loading={revokingId === i.id}
                onClick={() => handleRevoke(i.id)}
              >
                Revoke
              </Button>
            ),
          },
        ]
      : []),
  ];

  return (
    <div className="flex flex-col gap-8">
      <div>
        <div className="mb-3 flex items-center justify-between">
          <h2 className="font-semibold text-ink-primary dark:text-ink-primary-dark">Members</h2>
          {canManageTeam && <Button size="sm" onClick={() => setInviteOpen(true)}>Invite member</Button>}
        </div>
        <Table
          columns={memberColumns}
          data={members}
          rowKey={(m) => m.id}
          emptyState={<EmptyState title="No members yet" />}
        />
      </div>

      {canManageTeam && (
        <div>
          <h2 className="mb-3 font-semibold text-ink-primary dark:text-ink-primary-dark">Pending invitations</h2>
          <Table
            columns={invitationColumns}
            data={invitations}
            rowKey={(i) => i.id}
            emptyState={<EmptyState title="No pending invitations" />}
          />
        </div>
      )}

      <InviteMemberModal
        orgSlug={orgSlug}
        open={inviteOpen}
        onClose={() => setInviteOpen(false)}
        onInvited={() => router.refresh()}
      />
    </div>
  );
}
