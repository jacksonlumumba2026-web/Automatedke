import { Card } from "@/components/ui/Card";
import type { RolePermissionRow } from "@/lib/roles/queries";

const MODULE_LABELS: Record<string, string> = {
  organization: "Organization",
  team: "Team",
  roles: "Roles",
  billing: "Billing",
  notifications: "Notifications",
};

function summarize(row: RolePermissionRow | undefined): string {
  if (!row) return "—";
  const flags = [
    row.can_view && "V",
    row.can_create && "C",
    row.can_edit && "E",
    row.can_delete && "D",
    row.can_export && "X",
  ].filter(Boolean);
  return flags.length ? flags.join(",") : "—";
}

export function RolesTab({ permissions }: { permissions: RolePermissionRow[] }) {
  const roles = Array.from(new Set(permissions.map((p) => p.role)));
  const modules = Object.keys(MODULE_LABELS);

  return (
    <Card>
      <Card.Header>Role permissions</Card.Header>
      <Card.Body>
        <p className="mb-4 text-sm text-ink-secondary dark:text-ink-secondary-dark">
          V = View, C = Create, E = Edit, D = Delete, X = Export. Editing custom permissions per role is coming in a
          future update — see Permission_Matrix.md for the full rationale behind these defaults.
        </p>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="border-b border-border dark:border-border-dark">
              <tr>
                <th scope="col" className="px-3 py-2 font-medium text-ink-secondary dark:text-ink-secondary-dark">Role</th>
                {modules.map((mod) => (
                  <th key={mod} scope="col" className="px-3 py-2 font-medium text-ink-secondary dark:text-ink-secondary-dark">
                    {MODULE_LABELS[mod]}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-border dark:divide-border-dark">
              {roles.map((role) => (
                <tr key={role}>
                  <td className="whitespace-nowrap px-3 py-2 capitalize text-ink-primary dark:text-ink-primary-dark">
                    {role.replace("_", " ")}
                  </td>
                  {modules.map((mod) => (
                    <td key={mod} className="px-3 py-2 text-ink-secondary dark:text-ink-secondary-dark">
                      {summarize(permissions.find((p) => p.role === role && p.module === mod))}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card.Body>
    </Card>
  );
}
