import { Badge, EmptyState } from "@/components/ui";
import { Card } from "@/components/ui/Card";
import { statusToBadgeVariant } from "@/lib/rbac/constants";
import type { Subscription } from "@/lib/billing/queries";

const PLAN_LABELS: Record<string, string> = {
  free: "Free",
  starter: "Starter",
  professional: "Professional",
  business: "Business",
  enterprise: "Enterprise",
};

export function BillingTab({ subscription }: { subscription: Subscription | null }) {
  if (!subscription) {
    return (
      <Card>
        <Card.Body>
          <EmptyState title="No subscription found" description="Contact support if this looks wrong." />
        </Card.Body>
      </Card>
    );
  }

  return (
    <Card>
      <Card.Header>Your plan</Card.Header>
      <Card.Body>
        <div className="flex items-center justify-between">
          <div>
            <p className="text-lg font-semibold text-ink-primary dark:text-ink-primary-dark">
              {PLAN_LABELS[subscription.plan] ?? subscription.plan}
            </p>
            {subscription.current_period_end && (
              <p className="text-sm text-ink-secondary dark:text-ink-secondary-dark">
                Renews {new Date(subscription.current_period_end).toLocaleDateString()}
              </p>
            )}
          </div>
          <Badge variant={statusToBadgeVariant(subscription.status)}>{subscription.status}</Badge>
        </div>
        <p className="mt-4 text-sm text-ink-secondary dark:text-ink-secondary-dark">
          Plan upgrades and M-Pesa billing are coming in a future update — see Monetization_Strategy.md.
        </p>
      </Card.Body>
    </Card>
  );
}
