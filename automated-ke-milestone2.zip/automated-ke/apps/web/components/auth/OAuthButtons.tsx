"use client";

import { useState } from "react";

import { Button } from "@/components/ui/Button";
import { signInWithOAuth } from "@/lib/auth/actions";

export function OAuthButtons() {
  const [loadingProvider, setLoadingProvider] = useState<"google" | "azure" | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function handleClick(provider: "google" | "azure") {
    setError(null);
    setLoadingProvider(provider);
    const result = await signInWithOAuth(provider);
    if (result.error) {
      setError(result.error.message);
      setLoadingProvider(null);
      return;
    }
    window.location.href = result.data.url;
  }

  return (
    <div className="flex flex-col gap-3">
      <Button
        variant="secondary"
        size="lg"
        loading={loadingProvider === "google"}
        disabled={loadingProvider !== null}
        onClick={() => handleClick("google")}
      >
        Continue with Google
      </Button>
      <Button
        variant="secondary"
        size="lg"
        loading={loadingProvider === "azure"}
        disabled={loadingProvider !== null}
        onClick={() => handleClick("azure")}
      >
        Continue with Microsoft
      </Button>
      {error && (
        <p role="alert" className="text-sm text-danger">
          {error}
        </p>
      )}
    </div>
  );
}
