"use client";

import { useState, type FormEvent } from "react";

import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import { signUp } from "@/lib/auth/actions";

export function SignupForm() {
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fieldErrors, setFieldErrors] = useState<Record<string, string[]>>({});
  const [formError, setFormError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setFormError(null);
    setFieldErrors({});
    setSubmitting(true);

    const result = await signUp({ fullName, email, password });

    if (result.error) {
      setFieldErrors(result.error.details ?? {});
      if (result.error.code !== "VALIDATION_ERROR") {
        setFormError(result.error.message);
      }
      setSubmitting(false);
      return;
    }

    setSubmitted(true);
    setSubmitting(false);
  }

  if (submitted) {
    return (
      <div role="status" className="rounded-lg border border-border bg-surface p-6 text-center dark:border-border-dark dark:bg-surface-dark">
        <p className="font-medium text-ink-primary dark:text-ink-primary-dark">Check your email</p>
        <p className="mt-2 text-sm text-ink-secondary dark:text-ink-secondary-dark">
          We sent a verification link to {email}. Click it to activate your account.
        </p>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} noValidate className="flex flex-col gap-4">
      <Input
        label="Full name"
        autoComplete="name"
        required
        value={fullName}
        onChange={(e) => setFullName(e.target.value)}
        error={fieldErrors.fullName?.[0]}
      />
      <Input
        label="Email"
        type="email"
        autoComplete="email"
        required
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        error={fieldErrors.email?.[0]}
      />
      <Input
        label="Password"
        type="password"
        autoComplete="new-password"
        required
        helperText="At least 10 characters, including a number"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        error={fieldErrors.password?.[0]}
      />
      {formError && (
        <p role="alert" className="text-sm text-danger">
          {formError}
        </p>
      )}
      <Button type="submit" size="lg" loading={submitting}>
        Create account
      </Button>
    </form>
  );
}
