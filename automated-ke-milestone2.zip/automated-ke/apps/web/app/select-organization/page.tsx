import Link from "next/link";
import type { Metadata } from "next";

import { Avatar } from "@/components/ui";
import { requireAuth } from "@/lib/auth/session";
import { getUserOrganizations } from "@/lib/organizations/queries";

export const metadata: Metadata = { title: "Select an organization" };

export default async function SelectOrganizationPage() {
  await requireAuth();
  const memberships = await getUserOrganizations();

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4 dark:bg-background-dark">
      <div className="w-full max-w-sm">
        <h1 className="mb-6 text-center text-xl font-semibold text-ink-primary dark:text-ink-primary-dark">
          Choose an organization
        </h1>
        <ul className="flex flex-col gap-2">
          {memberships.map((m) =>
            m.organizations ? (
              <li key={m.organization_id}>
                <Link
                  href={`/${m.organizations.slug}/dashboard`}
                  className="flex items-center gap-3 rounded-lg border border-border bg-surface p-4 hover:bg-background dark:border-border-dark dark:bg-surface-dark dark:hover:bg-background-dark"
                >
                  <Avatar name={m.organizations.name} size="md" />
                  <div>
                    <p className="font-medium text-ink-primary dark:text-ink-primary-dark">
                      {m.organizations.name}
                    </p>
                    <p className="text-sm capitalize text-ink-secondary dark:text-ink-secondary-dark">
                      {m.role.replace("_", " ")}
                    </p>
                  </div>
                </Link>
              </li>
            ) : null
          )}
        </ul>
        <Link
          href="/onboarding/create-organization"
          className="mt-4 block text-center text-sm text-primary hover:underline dark:text-primary-dark"
        >
          + Create a new organization
        </Link>
      </div>
    </div>
  );
}
