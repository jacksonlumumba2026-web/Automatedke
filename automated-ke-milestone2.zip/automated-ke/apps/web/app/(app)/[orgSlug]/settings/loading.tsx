import { Skeleton } from "@/components/ui";

export default function SettingsLoading() {
  return (
    <div>
      <div className="mb-6 w-40">
        <Skeleton variant="text" />
      </div>
      <Skeleton variant="card" />
    </div>
  );
}
