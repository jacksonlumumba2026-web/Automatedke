import type { Metadata } from "next";

import { Tabs } from "@/components/ui/Tabs";
import { BillingTab } from "@/components/settings/BillingTab";
import { OrganizationTab } from "@/components/settings/OrganizationTab";
import { RolesTab } from "@/components/settings/RolesTab";
import { TeamTab } from "@/components/settings/TeamTab";
import { requireOrgAccess } from "@/lib/auth/guards";
import { getSubscription } from "@/lib/billing/queries";
import { getPendingInvitations, getTeamMembers } from "@/lib/invitations/queries";
import {
  canManageTeam,
  canUpdateOrganization,
  canViewBilling,
  canViewRoles,
} from "@/lib/rbac/permissions";
import { getRolePermissions } from "@/lib/roles/queries";

export const metadata: Metadata = { title: "Settings" };

export default async function SettingsPage({ params }: { params: Promise<{ orgSlug: string }> }) {
  const { orgSlug } = await params;
  const context = await requireOrgAccess(orgSlug);
  const { organization, role } = context;

  const showBilling = canViewBilling(role);
  const showRoles = canViewRoles(role);

  const [members, invitations, subscription, rolePermissions] = await Promise.all([
    getTeamMembers(organization.id),
    canManageTeam(role) ? getPendingInvitations(organization.id) : Promise.resolve([]),
    showBilling ? getSubscription(organization.id) : Promise.resolve(null),
    showRoles ? getRolePermissions(organization.id) : Promise.resolve([]),
  ]);

  const tabs = [
    {
      key: "organization",
      label: "Organization",
      content: (
        <OrganizationTab orgSlug={orgSlug} initialName={organization.name} canEdit={canUpdateOrganization(role)} />
      ),
    },
    {
      key: "team",
      label: "Team",
      content: (
        <TeamTab orgSlug={orgSlug} members={members} invitations={invitations} canManageTeam={canManageTeam(role)} />
      ),
    },
    ...(showRoles
      ? [{ key: "roles", label: "Roles", content: <RolesTab permissions={rolePermissions} /> }]
      : []),
    ...(showBilling
      ? [{ key: "billing", label: "Billing", content: <BillingTab subscription={subscription} /> }]
      : []),
  ];

  return (
    <div>
      <h1 className="mb-6 text-2xl font-semibold text-ink-primary dark:text-ink-primary-dark">Settings</h1>
      <Tabs tabs={tabs} />
    </div>
  );
}
