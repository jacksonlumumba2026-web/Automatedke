import { AppShell } from "@/components/layout/AppShell";
import { requireOrgAccess } from "@/lib/auth/guards";
import { createClient } from "@/lib/supabase/server";

export default async function OrgLayout({
  children,
  params,
}: {
  children: React.ReactNode;
  params: Promise<{ orgSlug: string }>;
}) {
  const { orgSlug } = await params;

  // Authoritative access check — see lib/auth/guards.ts. Everything
  // below this line can trust that the current user is an active member
  // of this organization.
  const orgContext = await requireOrgAccess(orgSlug);

  const supabase = await createClient();
  const { data: profile } = await supabase
    .from("users")
    .select("full_name")
    .eq("id", orgContext.user.id)
    .single();

  return (
    <AppShell
      orgContext={orgContext}
      userName={profile?.full_name || orgContext.user.email.split("@")[0]!}
      userEmail={orgContext.user.email}
    >
      {children}
    </AppShell>
  );
}
