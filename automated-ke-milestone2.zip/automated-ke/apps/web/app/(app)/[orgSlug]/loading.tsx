/**
 * Covers the [orgSlug] layout's own async work (requireOrgAccess +
 * profile fetch), which happens BEFORE AppShell/Sidebar render — so it
 * can't use those components' own loading states. Kept intentionally
 * generic (no nav shell) since we don't yet know the organization's
 * enabled_modules at this point.
 */
export default function OrgSegmentLoading() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background dark:bg-background-dark">
      <div
        role="status"
        aria-label="Loading"
        className="h-8 w-8 animate-spin rounded-full border-2 border-border border-t-primary dark:border-border-dark dark:border-t-primary-dark"
      />
    </div>
  );
}
