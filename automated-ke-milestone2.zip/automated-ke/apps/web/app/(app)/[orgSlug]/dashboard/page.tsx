import type { Metadata } from "next";

import { Badge, EmptyState, StatCard } from "@/components/ui";
import { Card } from "@/components/ui/Card";
import { requireOrgAccess } from "@/lib/auth/guards";
import { getRecentActivity } from "@/lib/organizations/activity";

export const metadata: Metadata = { title: "Dashboard" };

const MODULE_LABELS: Record<string, string> = {
  crm: "CRM",
  inventory: "Inventory",
  pos: "Point of Sale",
  accounting: "Accounting",
  payroll: "Payroll & HR",
};

function humanizeAction(entry: { action: string; entity_type: string }): string {
  const entity = entry.entity_type.replace(/_/g, " ");
  const verb = { insert: "created", update: "updated", delete: "removed" }[entry.action] ?? entry.action;
  return `${entity} ${verb}`;
}

export default async function DashboardPage({ params }: { params: Promise<{ orgSlug: string }> }) {
  const { orgSlug } = await params;
  const { organization } = await requireOrgAccess(orgSlug);
  const activity = await getRecentActivity(organization.id);

  const upcomingModules = organization.enabled_modules.filter((m) => m in MODULE_LABELS);

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-semibold text-ink-primary dark:text-ink-primary-dark">
          Welcome to {organization.name}
        </h1>
        <p className="mt-1 text-sm text-ink-secondary dark:text-ink-secondary-dark">
          Here&apos;s what&apos;s happening in your organization.
        </p>
      </div>

      {/* Placeholder KPIs — populated with real data starting Phase 2,
          per design_system.md's "Dashboard Shell" spec. */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        <StatCard label="Team members" value="1" icon={<UsersIcon />} />
        <StatCard label="Plan" value="Free" icon={<PlanIcon />} />
        <StatCard label="Modules enabled" value={organization.enabled_modules.length} icon={<ModulesIcon />} />
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <Card.Header>Recent activity</Card.Header>
          <Card.Body>
            {activity.length === 0 ? (
              <EmptyState
                title="No activity yet"
                description="Actions taken in your organization will show up here."
              />
            ) : (
              <ul className="flex flex-col gap-3">
                {activity.map((entry) => (
                  <li key={entry.id} className="flex items-center justify-between text-sm">
                    <span className="capitalize text-ink-primary dark:text-ink-primary-dark">
                      {humanizeAction(entry)}
                    </span>
                    <span className="text-ink-secondary dark:text-ink-secondary-dark">
                      {new Date(entry.created_at).toLocaleDateString()}
                    </span>
                  </li>
                ))}
              </ul>
            )}
          </Card.Body>
        </Card>

        <Card>
          <Card.Header>Coming soon</Card.Header>
          <Card.Body>
            {upcomingModules.length === 0 ? (
              <p className="text-sm text-ink-secondary dark:text-ink-secondary-dark">
                All caught up — no additional modules queued for this organization.
              </p>
            ) : (
              <ul className="flex flex-col gap-3">
                {upcomingModules.map((mod) => (
                  <li key={mod} className="flex items-center justify-between text-sm">
                    <span className="text-ink-primary dark:text-ink-primary-dark">{MODULE_LABELS[mod]}</span>
                    <Badge variant="info">Coming in a future phase</Badge>
                  </li>
                ))}
              </ul>
            )}
          </Card.Body>
        </Card>
      </div>
    </div>
  );
}

function iconProps() {
  return { width: 20, height: 20, viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: 2 } as const;
}
function UsersIcon() {
  return (
    <svg {...iconProps()}>
      <circle cx="9" cy="8" r="3" />
      <path d="M2 21v-1a6 6 0 0112 0v1" />
      <path d="M16 4a3 3 0 010 6" />
      <path d="M22 21v-1a5.5 5.5 0 00-4-5.3" />
    </svg>
  );
}
function PlanIcon() {
  return (
    <svg {...iconProps()}>
      <path d="M12 2l3 7h7l-5.5 4.5L18 21l-6-4-6 4 1.5-7.5L2 9h7z" />
    </svg>
  );
}
function ModulesIcon() {
  return (
    <svg {...iconProps()}>
      <rect x="3" y="3" width="7" height="7" rx="1" />
      <rect x="14" y="3" width="7" height="7" rx="1" />
      <rect x="3" y="14" width="7" height="7" rx="1" />
      <rect x="14" y="14" width="7" height="7" rx="1" />
    </svg>
  );
}
