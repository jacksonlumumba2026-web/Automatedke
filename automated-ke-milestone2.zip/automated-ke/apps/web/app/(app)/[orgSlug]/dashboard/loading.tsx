import { Skeleton } from "@/components/ui";
import { Card } from "@/components/ui/Card";

/**
 * Matches the real dashboard's layout exactly (3 stat cards, a 2-col
 * activity card, a 1-col "coming soon" card) so there's no layout shift
 * when the real content replaces this. Closes the gap flagged in the
 * Milestone 1 accessibility/UI-standards follow-up — Section 10 of
 * CLAUDE.md requires a loading state on every screen, and this route had
 * none.
 */
export default function DashboardLoading() {
  return (
    <div className="flex flex-col gap-6">
      <div>
        <Skeleton variant="text" />
        <div className="mt-2 w-2/3">
          <Skeleton variant="text" />
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        <Skeleton variant="stat-card" />
        <Skeleton variant="stat-card" />
        <Skeleton variant="stat-card" />
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <Card.Header>Recent activity</Card.Header>
          <Card.Body>
            <Skeleton variant="table-row" count={4} />
          </Card.Body>
        </Card>
        <Card>
          <Card.Header>Coming soon</Card.Header>
          <Card.Body>
            <Skeleton variant="table-row" count={2} />
          </Card.Body>
        </Card>
      </div>
    </div>
  );
}
