import type { Metadata } from "next";
import { Inter } from "next/font/google";

import { PendingToastConsumer } from "@/components/layout/PendingToastConsumer";
import { ToastProvider } from "@/components/ui/Toast";

import "./globals.css";

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  display: "swap",
});

export const metadata: Metadata = {
  title: {
    default: "Automated KE — Run your business, automatically",
    template: "%s | Automated KE",
  },
  description:
    "CRM, accounting, inventory, HR, and AI automation in one platform, built for Kenyan and African businesses.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={inter.variable} suppressHydrationWarning>
      <body className="min-h-screen bg-background font-sans text-ink-primary antialiased dark:bg-background-dark dark:text-ink-primary-dark">
        <ToastProvider>
          <PendingToastConsumer />
          {children}
        </ToastProvider>
      </body>
    </html>
  );
}
