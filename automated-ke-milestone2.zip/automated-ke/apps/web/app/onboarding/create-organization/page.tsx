import type { Metadata } from "next";

import { CreateOrganizationForm } from "@/components/onboarding/CreateOrganizationForm";

export const metadata: Metadata = { title: "Create your organization" };

export default function CreateOrganizationPage() {
  return (
    <div className="flex flex-col gap-6">
      <div className="text-center">
        <h1 className="text-xl font-semibold text-ink-primary dark:text-ink-primary-dark">
          Set up your organization
        </h1>
        <p className="mt-1 text-sm text-ink-secondary dark:text-ink-secondary-dark">
          This is the workspace your team will use — you can invite people once it&apos;s created.
        </p>
      </div>
      <CreateOrganizationForm />
    </div>
  );
}
