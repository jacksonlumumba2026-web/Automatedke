import { requireAuth } from "@/lib/auth/session";

export default async function OnboardingLayout({ children }: { children: React.ReactNode }) {
  await requireAuth();

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4 dark:bg-background-dark">
      <div className="w-full max-w-md">{children}</div>
    </div>
  );
}
