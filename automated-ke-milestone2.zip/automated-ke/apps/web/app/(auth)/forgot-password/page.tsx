"use client";

import Link from "next/link";
import { useState, type FormEvent } from "react";

import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import { requestPasswordReset } from "@/lib/auth/actions";

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [sent, setSent] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    setError(null);
    const result = await requestPasswordReset({ email });
    setSubmitting(false);
    if (result.error) {
      setError(result.error.message);
      return;
    }
    setSent(true);
  }

  if (sent) {
    return (
      <div role="status" className="text-center">
        <p className="font-medium text-ink-primary dark:text-ink-primary-dark">Check your email</p>
        <p className="mt-2 text-sm text-ink-secondary dark:text-ink-secondary-dark">
          If an account exists for {email}, a reset link has been sent.
        </p>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-6">
      <h1 className="text-center text-xl font-semibold text-ink-primary dark:text-ink-primary-dark">
        Reset your password
      </h1>
      <form onSubmit={handleSubmit} noValidate className="flex flex-col gap-4">
        <Input
          label="Email"
          type="email"
          autoComplete="email"
          required
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        {error && (
          <p role="alert" className="text-sm text-danger">
            {error}
          </p>
        )}
        <Button type="submit" size="lg" loading={submitting}>
          Send reset link
        </Button>
      </form>
      <p className="text-center text-sm text-ink-secondary dark:text-ink-secondary-dark">
        <Link href="/login" className="text-primary hover:underline dark:text-primary-dark">
          Back to sign in
        </Link>
      </p>
    </div>
  );
}
