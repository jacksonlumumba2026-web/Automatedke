"use client";

import { useRouter } from "next/navigation";
import { useState, type FormEvent } from "react";

import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import { resetPassword } from "@/lib/auth/actions";
import { setPendingToast } from "@/lib/toast/pending";

export default function ResetPasswordPage() {
  const router = useRouter();
  const [password, setPassword] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    setError(null);
    const result = await resetPassword({ password });
    setSubmitting(false);
    if (result.error) {
      setError(result.error.message);
      return;
    }
    setPendingToast("Your password has been updated. Please sign in.", "success");
    router.push("/login");
  }

  return (
    <div className="flex flex-col gap-6">
      <h1 className="text-center text-xl font-semibold text-ink-primary dark:text-ink-primary-dark">
        Set a new password
      </h1>
      <form onSubmit={handleSubmit} noValidate className="flex flex-col gap-4">
        <Input
          label="New password"
          type="password"
          autoComplete="new-password"
          required
          helperText="At least 10 characters, including a number"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
        {error && (
          <p role="alert" className="text-sm text-danger">
            {error}
          </p>
        )}
        <Button type="submit" size="lg" loading={submitting}>
          Update password
        </Button>
      </form>
    </div>
  );
}
