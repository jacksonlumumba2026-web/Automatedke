"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { use, useEffect, useState } from "react";

import { Button } from "@/components/ui/Button";
import { acceptInvitation } from "@/lib/invitations/actions";
import { setPendingToast } from "@/lib/toast/pending";

export default function AcceptInvitePage({ params }: { params: Promise<{ token: string }> }) {
  const { token } = use(params);
  const router = useRouter();
  const [state, setState] = useState<"loading" | "error">("loading");
  const [errorMessage, setErrorMessage] = useState("");
  const [errorCode, setErrorCode] = useState("");

  useEffect(() => {
    let cancelled = false;

    async function run() {
      const result = await acceptInvitation(token);
      if (cancelled) return;

      if (result.error) {
        setErrorCode(result.error.code);
        setErrorMessage(result.error.message);
        setState("error");
        return;
      }

      setPendingToast("Welcome to the team!", "success");
      router.push(`/${result.data.orgSlug}/dashboard`);
    }

    run();
    return () => {
      cancelled = true;
    };
  }, [token, router]);

  if (state === "loading") {
    return (
      <div className="flex flex-col items-center gap-4 py-8">
        <div
          role="status"
          aria-label="Accepting invitation"
          className="h-8 w-8 animate-spin rounded-full border-2 border-border border-t-primary dark:border-border-dark dark:border-t-primary-dark"
        />
        <p className="text-sm text-ink-secondary dark:text-ink-secondary-dark">Accepting your invitation…</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center gap-4 text-center">
      <h1 className="text-xl font-semibold text-ink-primary dark:text-ink-primary-dark">
        {errorCode === "AUTH_REQUIRED" ? "Sign in to continue" : "Couldn't accept this invitation"}
      </h1>
      <p className="text-sm text-ink-secondary dark:text-ink-secondary-dark">{errorMessage}</p>
      <Link href={errorCode === "AUTH_REQUIRED" ? `/login?redirectTo=/accept-invite/${token}` : "/login"}>
        <Button>{errorCode === "AUTH_REQUIRED" ? "Sign in" : "Go to sign in"}</Button>
      </Link>
    </div>
  );
}
