import Link from "next/link";
import type { Metadata } from "next";

import { OAuthButtons } from "@/components/auth/OAuthButtons";
import { SignupForm } from "@/components/auth/SignupForm";

export const metadata: Metadata = { title: "Create your account" };

export default function SignupPage() {
  return (
    <div className="flex flex-col gap-6">
      <h1 className="text-center text-xl font-semibold text-ink-primary dark:text-ink-primary-dark">
        Create your account
      </h1>
      <OAuthButtons />
      <div className="flex items-center gap-3 text-xs text-ink-secondary dark:text-ink-secondary-dark">
        <div className="h-px flex-1 bg-border dark:bg-border-dark" />
        or
        <div className="h-px flex-1 bg-border dark:bg-border-dark" />
      </div>
      <SignupForm />
      <p className="text-center text-sm text-ink-secondary dark:text-ink-secondary-dark">
        Already have an account?{" "}
        <Link href="/login" className="text-primary hover:underline dark:text-primary-dark">
          Sign in
        </Link>
      </p>
    </div>
  );
}
