import Link from "next/link";
import type { Metadata } from "next";

import { LoginForm } from "@/components/auth/LoginForm";
import { OAuthButtons } from "@/components/auth/OAuthButtons";

export const metadata: Metadata = { title: "Sign in" };

export default function LoginPage() {
  return (
    <div className="flex flex-col gap-6">
      <h1 className="text-center text-xl font-semibold text-ink-primary dark:text-ink-primary-dark">
        Welcome back
      </h1>
      <OAuthButtons />
      <div className="flex items-center gap-3 text-xs text-ink-secondary dark:text-ink-secondary-dark">
        <div className="h-px flex-1 bg-border dark:bg-border-dark" />
        or
        <div className="h-px flex-1 bg-border dark:bg-border-dark" />
      </div>
      <LoginForm />
      <p className="text-center text-sm text-ink-secondary dark:text-ink-secondary-dark">
        <Link href="/forgot-password" className="text-primary hover:underline dark:text-primary-dark">
          Forgot your password?
        </Link>
      </p>
      <p className="text-center text-sm text-ink-secondary dark:text-ink-secondary-dark">
        Don&apos;t have an account?{" "}
        <Link href="/signup" className="text-primary hover:underline dark:text-primary-dark">
          Sign up
        </Link>
      </p>
    </div>
  );
}
