import Link from "next/link";

import { Button } from "@/components/ui/Button";

export default function NotFound() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-background px-4 text-center dark:bg-background-dark">
      <h1 className="text-xl font-semibold text-ink-primary dark:text-ink-primary-dark">Page not found</h1>
      <p className="max-w-sm text-sm text-ink-secondary dark:text-ink-secondary-dark">
        This page doesn&apos;t exist, or you don&apos;t have access to it.
      </p>
      <Link href="/">
        <Button>Go home</Button>
      </Link>
    </div>
  );
}
