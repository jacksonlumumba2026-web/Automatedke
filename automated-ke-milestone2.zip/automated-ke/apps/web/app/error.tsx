"use client";

import { useEffect } from "react";

import { Button } from "@/components/ui/Button";

export default function GlobalError({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  useEffect(() => {
    // In production this reports to the error-tracking service configured
    // per Engineering_Standards.md Section 3.2 (e.g. Sentry) — that
    // integration is wired up in a later hardening pass, not Phase 1.
    // eslint-disable-next-line no-console -- placeholder until error tracking is wired up
    console.error(error);
  }, [error]);

  return (
    <html lang="en">
      <body className="flex min-h-screen flex-col items-center justify-center gap-4 bg-background px-4 text-center dark:bg-background-dark">
        <h1 className="text-xl font-semibold text-ink-primary dark:text-ink-primary-dark">
          Something went wrong
        </h1>
        <p className="max-w-sm text-sm text-ink-secondary dark:text-ink-secondary-dark">
          We hit an unexpected error. Try again, and if it keeps happening, let us know.
        </p>
        <Button onClick={reset}>Try again</Button>
      </body>
    </html>
  );
}
