import { NextResponse } from "next/server";

import { createClient } from "@/lib/supabase/server";

/**
 * Exchanges the code from an OAuth redirect or an email verification /
 * password reset link for a session cookie. This is the landing point
 * configured as `emailRedirectTo` / OAuth `redirectTo` throughout
 * lib/auth/actions.ts.
 */
export async function GET(request: Request) {
  const { searchParams, origin } = new URL(request.url);
  const code = searchParams.get("code");
  const next = searchParams.get("next") ?? "/";

  if (code) {
    const supabase = await createClient();
    const { error } = await supabase.auth.exchangeCodeForSession(code);
    if (!error) {
      return NextResponse.redirect(`${origin}${next}`);
    }
  }

  // Per Authentication_Specification.md Section 9: a specific, non-alarming
  // message, not a raw provider/error dump.
  return NextResponse.redirect(`${origin}/login?error=auth_callback_failed`);
}
