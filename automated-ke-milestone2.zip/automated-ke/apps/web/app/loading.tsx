export default function RootLoading() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background dark:bg-background-dark">
      <div
        role="status"
        aria-label="Loading"
        className="h-8 w-8 animate-spin rounded-full border-2 border-border border-t-primary dark:border-border-dark dark:border-t-primary-dark"
      />
    </div>
  );
}
