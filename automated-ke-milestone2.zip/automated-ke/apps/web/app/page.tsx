import { redirect } from "next/navigation";

import { requireAuth } from "@/lib/auth/session";
import { getUserOrganizations } from "@/lib/organizations/queries";

/**
 * Per Authentication_Specification.md Section 6.4: zero orgs -> onboarding,
 * exactly one -> straight to its dashboard, more than one -> switcher.
 * This page never renders content itself — it only decides where to send
 * the user, on every visit to "/".
 */
export default async function RootPage() {
  await requireAuth();
  const memberships = await getUserOrganizations();

  if (memberships.length === 0) {
    redirect("/onboarding/create-organization");
  }

  if (memberships.length === 1) {
    const slug = memberships[0]?.organizations?.slug;
    if (slug) {
      redirect(`/${slug}/dashboard`);
    }
  }

  redirect("/select-organization");
}
