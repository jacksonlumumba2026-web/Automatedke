"use client";

import { createContext, useContext, type ReactNode } from "react";

import type { OrgRole } from "@/lib/rbac/constants";

export type OrganizationContextValue = {
  organization: { id: string; name: string; slug: string; enabled_modules: string[] };
  role: OrgRole;
};

const OrganizationContext = createContext<OrganizationContextValue | null>(null);

/**
 * Wraps the [orgSlug] route tree. The value passed in comes exclusively
 * from requireOrgAccess() (server-side, RLS-backed) — this provider only
 * distributes that already-verified value to client components for
 * display purposes (active nav state, org name in the topbar, etc.). It
 * is NOT itself a source of authorization; nothing here re-checks access.
 */
export function OrganizationProvider({
  value,
  children,
}: {
  value: OrganizationContextValue;
  children: ReactNode;
}) {
  return <OrganizationContext.Provider value={value}>{children}</OrganizationContext.Provider>;
}

export function useOrganization(): OrganizationContextValue {
  const ctx = useContext(OrganizationContext);
  if (!ctx) {
    throw new Error("useOrganization() must be used within an OrganizationProvider");
  }
  return ctx;
}
