"use client";

import {
  canManageBilling,
  canManageRoles,
  canManageTeam,
  canUpdateOrganization,
} from "@/lib/rbac/permissions";

import { useOrganization } from "./use-organization";

export function usePermissions() {
  const { role } = useOrganization();
  return {
    canManageTeam: canManageTeam(role),
    canManageRoles: canManageRoles(role),
    canManageBilling: canManageBilling(role),
    canUpdateOrganization: canUpdateOrganization(role),
  };
}
