-- =============================================================================
-- Migration: Performance advisor fixes
-- Found by running `supabase get_advisors` (performance) against a real
-- deployed instance — three real, distinct issues:
-- =============================================================================

-- --- Fix 1: unindexed foreign keys -------------------------------------------
create index idx_audit_logs_user on audit_logs (user_id);
create index idx_invitations_invited_by on invitations (invited_by);
create index idx_org_members_invited_by on organization_members (invited_by);
create index idx_team_members_user on team_members (user_id);

-- --- Fix 2: wrap auth.<fn>() in (select ...) to avoid per-row re-evaluation --
-- auth.uid() called directly in a policy gets re-evaluated for every row
-- scanned; wrapping it in a subquery lets Postgres evaluate it once per
-- query and treat it as a stable constant. Behaviorally identical,
-- meaningfully faster at scale. Re-creating each affected policy with
-- the wrapped form.

drop policy "authenticated users can create an organization" on organizations;
create policy "authenticated users can create an organization"
  on organizations for insert
  with check ((select auth.uid()) is not null);

drop policy "users can update their own profile" on users;
create policy "users can update their own profile"
  on users for update
  using (id = (select auth.uid()));

drop policy "users can view their own notifications" on notifications;
drop policy "users can mark their own notifications read" on notifications;
create policy "users can view their own notifications"
  on notifications for select
  using (user_id = (select auth.uid()));
create policy "users can mark their own notifications read"
  on notifications for update
  using (user_id = (select auth.uid()));

-- --- Fix 3: collapse redundant overlapping permissive policies ---------------
-- users: "own profile" and "co-members' profiles" were two separate
-- permissive SELECT policies (Postgres evaluates every permissive policy
-- and ORs the results — two policies costs more than one policy with an
-- OR baked in, for the identical outcome). Both conditions are still
-- needed: a user with zero org memberships isn't covered by the
-- co-members clause, so the self-view clause can't simply be dropped.
drop policy "users can view their own profile" on users;
drop policy "org members can view co-members' profiles" on users;
create policy "users can view own profile or org co-members' profiles"
  on users for select
  using (
    id = (select auth.uid())
    or id in (
      select om.user_id from organization_members om
      where om.organization_id in (select user_org_ids())
    )
  );

-- teams: "managers and above can manage teams" was FOR ALL, which
-- includes SELECT — fully redundant with "members can view teams in
-- their org" (a superset: every manager is already a member). Scoping
-- the manage policy to write operations only removes the SELECT overlap
-- without changing who can see what.
drop policy "managers and above can manage teams" on teams;
create policy "managers and above can create teams"
  on teams for insert
  with check (organization_id in (select user_org_ids())
              and user_role_in_org(organization_id) in ('owner', 'admin', 'manager'));
create policy "managers and above can update teams"
  on teams for update
  using (organization_id in (select user_org_ids())
         and user_role_in_org(organization_id) in ('owner', 'admin', 'manager'));
create policy "managers and above can delete teams"
  on teams for delete
  using (organization_id in (select user_org_ids())
         and user_role_in_org(organization_id) in ('owner', 'admin', 'manager'));
