"use client";

import { useEffect, useRef, useState } from "react";

import { Badge } from "@/components/ui";
import { markAllNotificationsRead, markNotificationRead } from "@/lib/organizations/notification-actions";
import type { NotificationItem } from "@/lib/organizations/notifications";

/**
 * Phase 1 scope only: unread count + list, in-app only. Per
 * Phase1_Architecture.md Step 8, email/SMS/WhatsApp delivery channels
 * are Phase 5 work — this component deliberately does not attempt them.
 */
export function NotificationBell({
  orgSlug,
  organizationId,
  initialNotifications,
  initialUnreadCount,
}: {
  orgSlug: string;
  organizationId: string;
  initialNotifications: NotificationItem[];
  initialUnreadCount: number;
}) {
  const [open, setOpen] = useState(false);
  const [notifications, setNotifications] = useState(initialNotifications);
  const [unreadCount, setUnreadCount] = useState(initialUnreadCount);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  async function handleMarkRead(id: string) {
    const wasUnread = notifications.find((n) => n.id === id && !n.read_at);
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, read_at: new Date().toISOString() } : n)));
    if (wasUnread) setUnreadCount((c) => Math.max(0, c - 1));
    await markNotificationRead(orgSlug, id);
  }

  async function handleMarkAllRead() {
    const now = new Date().toISOString();
    setNotifications((prev) => prev.map((n) => ({ ...n, read_at: n.read_at ?? now })));
    setUnreadCount(0);
    await markAllNotificationsRead(orgSlug, organizationId);
  }

  return (
    <div ref={containerRef} className="relative">
      <button
        type="button"
        aria-haspopup="menu"
        aria-expanded={open}
        aria-label={unreadCount > 0 ? `Notifications, ${unreadCount} unread` : "Notifications"}
        onClick={() => setOpen((v) => !v)}
        className="relative rounded-full p-2 text-ink-secondary hover:bg-background hover:text-ink-primary focus-visible:outline-none dark:text-ink-secondary-dark dark:hover:bg-background-dark dark:hover:text-ink-primary-dark"
      >
        <BellIcon />
        {unreadCount > 0 && (
          <span
            aria-hidden="true"
            className="absolute right-1 top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-danger px-1 text-[10px] font-medium text-white"
          >
            {unreadCount > 9 ? "9+" : unreadCount}
          </span>
        )}
      </button>

      {open && (
        <div
          role="menu"
          aria-label="Notifications"
          className="absolute right-0 z-10 mt-2 w-80 rounded-lg border border-border bg-surface shadow-lg dark:border-border-dark dark:bg-surface-dark"
        >
          <div className="flex items-center justify-between border-b border-border px-4 py-2 dark:border-border-dark">
            <span className="text-sm font-medium text-ink-primary dark:text-ink-primary-dark">Notifications</span>
            {unreadCount > 0 && (
              <button
                type="button"
                onClick={handleMarkAllRead}
                className="text-xs text-primary hover:underline focus-visible:outline-none dark:text-primary-dark"
              >
                Mark all read
              </button>
            )}
          </div>
          <ul className="max-h-80 overflow-y-auto">
            {notifications.length === 0 ? (
              <li className="px-4 py-6 text-center text-sm text-ink-secondary dark:text-ink-secondary-dark">
                Nothing here yet.
              </li>
            ) : (
              notifications.map((n) => (
                <li key={n.id} className="border-b border-border last:border-0 dark:border-border-dark">
                  <button
                    type="button"
                    role="menuitem"
                    onClick={() => handleMarkRead(n.id)}
                    className="flex w-full flex-col items-start gap-0.5 px-4 py-3 text-left hover:bg-background focus-visible:outline-none dark:hover:bg-background-dark"
                  >
                    <div className="flex w-full items-center justify-between gap-2">
                      <span className="text-sm font-medium text-ink-primary dark:text-ink-primary-dark">
                        {n.title}
                      </span>
                      {!n.read_at && <Badge variant="info">New</Badge>}
                    </div>
                    {n.body && (
                      <span className="text-xs text-ink-secondary dark:text-ink-secondary-dark">{n.body}</span>
                    )}
                    <span className="text-xs text-ink-secondary dark:text-ink-secondary-dark">
                      {new Date(n.created_at).toLocaleDateString()}
                    </span>
                  </button>
                </li>
              ))
            )}
          </ul>
        </div>
      )}
    </div>
  );
}

function BellIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} aria-hidden="true">
      <path d="M18 8a6 6 0 10-12 0c0 7-3 9-3 9h18s-3-2-3-9" />
      <path d="M13.73 21a2 2 0 01-3.46 0" />
    </svg>
  );
}
