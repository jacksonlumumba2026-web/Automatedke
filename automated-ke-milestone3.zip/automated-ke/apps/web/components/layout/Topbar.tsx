import { NotificationBell } from "./NotificationBell";
import { OrgSwitcher } from "./OrgSwitcher";
import { UserMenu } from "./UserMenu";
import type { UserOrgMembership } from "@/lib/organizations/queries";
import type { NotificationItem } from "@/lib/organizations/notifications";

export function Topbar({
  memberships,
  orgSlug,
  organizationId,
  notifications,
  unreadCount,
  userName,
  userEmail,
}: {
  memberships: UserOrgMembership[];
  orgSlug: string;
  organizationId: string;
  notifications: NotificationItem[];
  unreadCount: number;
  userName: string;
  userEmail: string;
}) {
  return (
    <header className="flex h-16 items-center justify-between border-b border-border bg-surface px-4 dark:border-border-dark dark:bg-surface-dark md:px-6">
      <OrgSwitcher memberships={memberships} />
      <div className="flex items-center gap-2">
        <NotificationBell
          orgSlug={orgSlug}
          organizationId={organizationId}
          initialNotifications={notifications}
          initialUnreadCount={unreadCount}
        />
        <UserMenu userName={userName} userEmail={userEmail} />
      </div>
    </header>
  );
}
