"use client";

import { useEffect, useRef, type ReactNode } from "react";
import { createPortal } from "react-dom";

import { cn } from "@/lib/utils/cn";

export type ModalProps = {
  open: boolean;
  onClose: () => void;
  title: string;
  description?: string;
  size?: "sm" | "md" | "lg";
  preventBackdropClose?: boolean;
  children: ReactNode;
};

const sizeStyles = { sm: "max-w-sm", md: "max-w-md", lg: "max-w-2xl" };

const FOCUSABLE_SELECTOR =
  'a[href], button:not([disabled]), textarea, input, select, [tabindex]:not([tabindex="-1"])';

export function Modal({ open, onClose, title, description, size = "md", preventBackdropClose, children }: ModalProps) {
  const dialogRef = useRef<HTMLDivElement>(null);
  const previouslyFocused = useRef<HTMLElement | null>(null);

  // Focus trap + Esc-to-close + focus restore on close.
  useEffect(() => {
    if (!open) return;

    previouslyFocused.current = document.activeElement as HTMLElement;
    const dialog = dialogRef.current;
    const focusables = dialog?.querySelectorAll<HTMLElement>(FOCUSABLE_SELECTOR);
    focusables?.[0]?.focus();

    function handleKeyDown(e: KeyboardEvent) {
      if (e.key === "Escape" && !preventBackdropClose) {
        onClose();
        return;
      }
      if (e.key === "Tab" && dialog) {
        const nodes = Array.from(dialog.querySelectorAll<HTMLElement>(FOCUSABLE_SELECTOR));
        if (nodes.length === 0) return;
        const first = nodes[0]!;
        const last = nodes[nodes.length - 1]!;
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first.focus();
        }
      }
    }

    document.addEventListener("keydown", handleKeyDown);
    return () => {
      document.removeEventListener("keydown", handleKeyDown);
      previouslyFocused.current?.focus();
    };
  }, [open, onClose, preventBackdropClose]);

  if (!open) return null;

  const titleId = "modal-title";
  const descriptionId = "modal-description";

  return createPortal(
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div
        aria-hidden="true"
        // eslint-disable-next-line jsx-a11y/no-static-element-interactions, jsx-a11y/click-events-have-key-events -- decorative backdrop only; aria-hidden removes it from the AT tree entirely, and keyboard/screen-reader users close via Escape or the Cancel button, not this div
        onClick={() => !preventBackdropClose && onClose()}
        className="absolute inset-0 bg-black/40"
      />
      <div
        ref={dialogRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        aria-describedby={description ? descriptionId : undefined}
        className={cn(
          "relative w-full rounded-lg border border-border bg-surface p-6 shadow-xl dark:border-border-dark dark:bg-surface-dark",
          sizeStyles[size]
        )}
      >
        <h2 id={titleId} className="text-lg font-semibold text-ink-primary dark:text-ink-primary-dark">
          {title}
        </h2>
        {description && (
          <p id={descriptionId} className="mt-1 text-sm text-ink-secondary dark:text-ink-secondary-dark">
            {description}
          </p>
        )}
        <div className="mt-4">{children}</div>
      </div>
    </div>,
    document.body
  );
}
