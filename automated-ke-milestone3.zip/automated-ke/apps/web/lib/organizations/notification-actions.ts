"use server";

import { revalidatePath } from "next/cache";

import { requireAuth } from "@/lib/auth/session";
import { fail, mapSupabaseError, ok, type AppResult } from "@/lib/errors";
import { createClient } from "@/lib/supabase/server";

export async function markNotificationRead(
  orgSlug: string,
  notificationId: string
): Promise<AppResult<{ read: true }>> {
  await requireAuth();
  const supabase = await createClient();

  // No explicit user_id check needed here beyond auth — RLS ("users can
  // mark their own notifications read": user_id = auth.uid()) is what
  // actually prevents marking someone else's notification read; this
  // call simply cannot succeed against a row that isn't the caller's.
  const { error } = await supabase
    .from("notifications")
    .update({ read_at: new Date().toISOString() })
    .eq("id", notificationId);

  if (error) {
    const mapped = mapSupabaseError(error);
    return fail(mapped.code, mapped.message);
  }

  revalidatePath(`/${orgSlug}`);
  return ok({ read: true });
}

export async function markAllNotificationsRead(
  orgSlug: string,
  organizationId: string
): Promise<AppResult<{ read: true }>> {
  await requireAuth();
  const supabase = await createClient();

  const { error } = await supabase
    .from("notifications")
    .update({ read_at: new Date().toISOString() })
    .eq("organization_id", organizationId)
    .is("read_at", null);

  if (error) {
    const mapped = mapSupabaseError(error);
    return fail(mapped.code, mapped.message);
  }

  revalidatePath(`/${orgSlug}`);
  return ok({ read: true });
}
