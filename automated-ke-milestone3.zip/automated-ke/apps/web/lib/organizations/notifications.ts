import "server-only";

import { createClient } from "@/lib/supabase/server";

export async function getUnreadNotificationCount(organizationId: string): Promise<number> {
  const supabase = await createClient();
  const { count } = await supabase
    .from("notifications")
    .select("id", { count: "exact", head: true })
    .eq("organization_id", organizationId)
    .is("read_at", null);

  return count ?? 0;
}

export type NotificationItem = {
  id: string;
  type: string;
  title: string;
  body: string | null;
  read_at: string | null;
  created_at: string;
};

/**
 * RLS ("users can view their own notifications") scopes this to the
 * current user automatically — organizationId narrows it to the
 * currently-active org's notifications specifically, since a user with
 * multiple orgs shouldn't see one org's notifications while working in
 * another.
 */
export async function getRecentNotifications(organizationId: string, limit = 10): Promise<NotificationItem[]> {
  const supabase = await createClient();
  const { data } = await supabase
    .from("notifications")
    .select("id, type, title, body, read_at, created_at")
    .eq("organization_id", organizationId)
    .order("created_at", { ascending: false })
    .limit(limit);

  return data ?? [];
}
